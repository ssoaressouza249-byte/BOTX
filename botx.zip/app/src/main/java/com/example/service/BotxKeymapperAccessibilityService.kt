package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.util.DisplayMetrics
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import com.example.data.KeyCodeFormatter
import com.example.data.KeyMappingElement
import com.example.data.MappingElementType
import com.example.system.KeymapperRuntimeState
import com.example.system.ShizukuBridge
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.hypot
import kotlin.math.roundToInt

class BotxKeymapperAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val pressedWasdKeys = mutableSetOf<Int>()
    private var wasdLoopJob: Job? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        KeymapperRuntimeState.setAccessibilityConnected(true)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        KeymapperRuntimeState.setAccessibilityConnected(false)
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        KeymapperRuntimeState.setAccessibilityConnected(false)
        instance = null
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Active profile switching can be matched via event.packageName if desired
    }

    override fun onInterrupt() {
        pressedWasdKeys.clear()
        wasdLoopJob?.cancel()
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!KeymapperRuntimeState.isMappingActive.value) return false
        val profile = KeymapperRuntimeState.activeProfile.value

        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            KeymapperRuntimeState.reportInputEvent(
                "Tecla: ${KeyCodeFormatter.formatKeyOrMouse(event.keyCode, 0)}"
            )
            if (event.keyCode == profile.aimToggleKeyCode && profile.aimToggleKeyCode != KeyEvent.KEYCODE_UNKNOWN) {
                KeymapperRuntimeState.toggleAimMode()
                return true
            }
        }

        val hasWasd = profile.elements.any { it.type == MappingElementType.WASD_ANALOG }
        if (hasWasd && isWasdKey(event.keyCode)) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                if (pressedWasdKeys.add(event.keyCode)) {
                    restartWasdGestureLoop()
                }
            } else if (event.action == KeyEvent.ACTION_UP) {
                pressedWasdKeys.remove(event.keyCode)
                if (pressedWasdKeys.isEmpty()) {
                    wasdLoopJob?.cancel()
                } else {
                    restartWasdGestureLoop()
                }
            }
            return true
        }

        val matchingElements = profile.elements.filter {
            it.type != MappingElementType.WASD_ANALOG &&
                it.mouseButton == 0 &&
                it.keyCode == event.keyCode
        }
        if (matchingElements.isNotEmpty()) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                matchingElements.forEach { triggerElement(it) }
            }
            return true
        }
        return false
    }

    fun triggerMouseButton(button: Int) {
        if (!KeymapperRuntimeState.isMappingActive.value) return
        val profile = KeymapperRuntimeState.activeProfile.value
        val label = when (button) {
            MotionEvent.BUTTON_PRIMARY -> "MOUSE ESQ"
            MotionEvent.BUTTON_SECONDARY -> "MOUSE DIR"
            else -> "MOUSE #$button"
        }
        KeymapperRuntimeState.reportInputEvent("Botão: $label")
        profile.elements
            .filter { it.mouseButton == button }
            .forEach { triggerElement(it) }
    }

    private fun triggerElement(element: KeyMappingElement) {
        val (w, h) = getScreenDimensions()
        val x1 = (element.xFraction * w).roundToInt().coerceIn(1, w - 1)
        val y1 = (element.yFraction * h).roundToInt().coerceIn(1, h - 1)

        when (element.type) {
            MappingElementType.TAP -> {
                performSingleTap(x1.toFloat(), y1.toFloat())
            }
            MappingElementType.COMBO_MACRO -> {
                val x2 = (element.secondaryXFraction * w).roundToInt().coerceIn(1, w - 1)
                val y2 = (element.secondaryYFraction * h).roundToInt().coerceIn(1, h - 1)
                val delayMs = element.macroDelayMs.coerceIn(10, 500).toLong()
                serviceScope.launch {
                    performSingleTap(x1.toFloat(), y1.toFloat())
                    delay(delayMs)
                    performSingleTap(x2.toFloat(), y2.toFloat())
                }
            }
            MappingElementType.WASD_ANALOG -> Unit
        }
    }

    private fun restartWasdGestureLoop() {
        wasdLoopJob?.cancel()
        wasdLoopJob = serviceScope.launch {
            while (pressedWasdKeys.isNotEmpty() && KeymapperRuntimeState.isMappingActive.value) {
                val profile = KeymapperRuntimeState.activeProfile.value
                val wasd = profile.elements.firstOrNull { it.type == MappingElementType.WASD_ANALOG }
                    ?: break
                var dx = 0f
                var dy = 0f
                if (KeyEvent.KEYCODE_A in pressedWasdKeys) dx -= 1f
                if (KeyEvent.KEYCODE_D in pressedWasdKeys) dx += 1f
                if (KeyEvent.KEYCODE_W in pressedWasdKeys) dy -= 1f
                if (KeyEvent.KEYCODE_S in pressedWasdKeys) dy += 1f

                if (dx == 0f && dy == 0f) break
                val mag = hypot(dx, dy)
                dx /= mag
                dy /= mag

                val (w, h) = getScreenDimensions()
                val minDim = minOf(w, h).toFloat()
                val centerX = (wasd.xFraction * w).coerceIn(10f, w - 10f)
                val centerY = (wasd.yFraction * h).coerceIn(10f, h - 10f)
                val radiusPx = (wasd.radiusFraction * minDim).coerceAtLeast(48f)

                val targetX = (centerX + dx * radiusPx).coerceIn(10f, w - 10f)
                val targetY = (centerY + dy * radiusPx).coerceIn(10f, h - 10f)
                val swipeDuration = (140 + (profile.dragSmoothing * 140f).roundToInt()).coerceIn(90, 320)

                if (KeymapperRuntimeState.useShizukuInjection.value && ShizukuBridge.isReady()) {
                    serviceScope.launch(Dispatchers.IO) {
                        ShizukuBridge.injectSwipeAsync(
                            centerX.roundToInt(),
                            centerY.roundToInt(),
                            targetX.roundToInt(),
                            targetY.roundToInt(),
                            swipeDuration
                        )
                    }
                } else {
                    val path = Path().apply {
                        moveTo(centerX, centerY)
                        lineTo(targetX, targetY)
                    }
                    val stroke = GestureDescription.StrokeDescription(path, 0L, swipeDuration.toLong())
                    dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
                }
                delay(swipeDuration.toLong() + 10L)
            }
        }
    }

    private fun performSingleTap(x: Float, y: Float) {
        if (KeymapperRuntimeState.useShizukuInjection.value && ShizukuBridge.isReady()) {
            serviceScope.launch(Dispatchers.IO) {
                if (!ShizukuBridge.injectTapAsync(x.roundToInt(), y.roundToInt())) {
                    launch(Dispatchers.Main) { dispatchAccessibilityTap(x, y) }
                }
            }
        } else {
            dispatchAccessibilityTap(x, y)
        }
    }

    private fun dispatchAccessibilityTap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 28L)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    private fun isWasdKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_W ||
            keyCode == KeyEvent.KEYCODE_A ||
            keyCode == KeyEvent.KEYCODE_S ||
            keyCode == KeyEvent.KEYCODE_D
    }

    private fun getScreenDimensions(): Pair<Int, Int> {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            val bounds = wm.currentWindowMetrics.bounds
            bounds.width().coerceAtLeast(100) to bounds.height().coerceAtLeast(100)
        } else {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            metrics.widthPixels.coerceAtLeast(100) to metrics.heightPixels.coerceAtLeast(100)
        }
    }

    companion object {
        @Volatile
        var instance: BotxKeymapperAccessibilityService? = null
            private set

        fun dispatchMouseClickIfRunning(button: Int) {
            instance?.triggerMouseButton(button)
        }
    }
}
