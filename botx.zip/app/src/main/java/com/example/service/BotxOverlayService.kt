package com.example.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.KeyCodeFormatter
import com.example.data.KeyMappingElement
import com.example.data.MappingElementType
import com.example.system.KeymapperRuntimeState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.abs
import kotlin.math.roundToInt

class BotxOverlayService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var windowManager: WindowManager

    private var bubbleView: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null

    private var editorCanvas: FrameLayout? = null
    private var editorParams: WindowManager.LayoutParams? = null
    private var editorVisible = false

    private var awaitingBindElementId: String? = null
    private var awaitingAimToggleKey = false
    private var statusBanner: TextView? = null
    private var macroDelayContainer: LinearLayout? = null
    private var wasdSizeContainer: LinearLayout? = null
    private var selectedElementId: String? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundCompat()

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        KeymapperRuntimeState.setOverlayRunning(true)
        showFloatingBubble()

        scope.launch {
            KeymapperRuntimeState.activeProfile.collectLatest {
                if (editorVisible) {
                    rebuildMarkersLayer()
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_OVERLAY -> stopSelf()
            ACTION_OPEN_EDITOR -> if (!editorVisible) toggleEditor()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        KeymapperRuntimeState.setOverlayRunning(false)
        removeBubble()
        removeEditor()
        scope.cancel()
        super.onDestroy()
    }

    private fun startForegroundCompat() {
        val channelId = "botx_overlay_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                channelId,
                getString(R.string.overlay_notification_channel),
                NotificationManager.IMPORTANCE_LOW
            )
            nm.createNotificationChannel(channel)
        }
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(getString(R.string.overlay_notification_title))
            .setContentText(getString(R.string.overlay_notification_text))
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
        startForeground(1001, notification)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showFloatingBubble() {
        if (bubbleView != null) return
        val sizePx = dp(52)

        val bubble = TextView(this).apply {
            text = "BX"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#E6070709"))
                setStroke(dp(2), Color.parseColor("#FF1E42"))
            }
            elevation = dp(8).toFloat()
        }

        val params = WindowManager.LayoutParams(
            sizePx,
            sizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(18)
            y = dp(180)
        }

        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        bubble.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).roundToInt()
                    val dy = (event.rawY - touchY).roundToInt()
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    params.x = initialX + dx
                    params.y = initialY + dy
                    runCatching { windowManager.updateViewLayout(bubble, params) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        toggleEditor()
                    }
                    true
                }
                else -> false
            }
        }

        bubbleView = bubble
        bubbleParams = params
        runCatching { windowManager.addView(bubble, params) }
    }

    private fun toggleEditor() {
        if (editorVisible) {
            removeEditor()
        } else {
            showEditor()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showEditor() {
        if (editorCanvas != null) return
        editorVisible = true

        val root = object : FrameLayout(this) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    val bindId = awaitingBindElementId
                    if (bindId != null) {
                        val el = KeymapperRuntimeState.activeProfile.value.elements.firstOrNull { it.id == bindId }
                        if (el != null) {
                            KeymapperRuntimeState.addOrUpdateElement(
                                el.copy(
                                    keyCode = event.keyCode,
                                    mouseButton = 0,
                                    label = KeyCodeFormatter.formatKeyOrMouse(event.keyCode, 0)
                                )
                            )
                        }
                        awaitingBindElementId = null
                        updateStatusBanner("Vinculado: ${KeyCodeFormatter.formatKeyOrMouse(event.keyCode, 0)}")
                        return true
                    }
                    if (awaitingAimToggleKey) {
                        val cur = KeymapperRuntimeState.activeProfile.value
                        KeymapperRuntimeState.updateProfileFromOverlay(cur.copy(aimToggleKeyCode = event.keyCode))
                        awaitingAimToggleKey = false
                        updateStatusBanner("Tecla Mira/Cursor: ${KeyCodeFormatter.formatKeyOrMouse(event.keyCode, 0)}")
                        return true
                    }
                }
                return super.dispatchKeyEvent(event)
            }
        }.apply {
            setBackgroundColor(Color.parseColor("#55070709"))
            isFocusable = true
            isFocusableInTouchMode = true
        }

        val topBarContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#EE111216"))
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.parseColor("#FF1E42"))
            }
        }

        val banner = TextView(this).apply {
            text = "EDITOR BOTX • Arraste os pontos sobre o jogo"
            setTextColor(Color.parseColor("#F3F4F8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.MONOSPACE
            setPadding(dp(4), 0, dp(4), dp(6))
        }
        statusBanner = banner
        topBarContainer.addView(banner)

        val scrollRow = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
        }
        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        btnRow.addView(createActionChip("+ Tap") { addTapMarker() })
        btnRow.addView(createActionChip("+ WASD") { addWasdMarker() })
        btnRow.addView(createActionChip("+ Macro") { addMacroMarker() })
        btnRow.addView(createActionChip("Tecla Mira") {
            awaitingAimToggleKey = true
            awaitingBindElementId = null
            updateStatusBanner("Pressione uma tecla física para alternar Mira/Cursor (atual: ${KeyCodeFormatter.formatKeyOrMouse(KeymapperRuntimeState.activeProfile.value.aimToggleKeyCode, 0)})")
        })
        btnRow.addView(createActionChip("Mouse Esq") { bindSelectedToMouse(MotionEvent.BUTTON_PRIMARY) })
        btnRow.addView(createActionChip("Mouse Dir") { bindSelectedToMouse(MotionEvent.BUTTON_SECONDARY) })
        btnRow.addView(createActionChip("Modo: ${if (KeymapperRuntimeState.isMappingActive.value) "ON" else "OFF"}") {
            val next = !KeymapperRuntimeState.isMappingActive.value
            KeymapperRuntimeState.setMappingActive(next)
            updateStatusBanner("Mapeamento ${if (next) "ATIVADO" else "PAUSADO"}")
        })
        btnRow.addView(createActionChip("Minimizar", "#3A1620") { toggleEditor() })
        btnRow.addView(createActionChip("Encerrar", "#8B0018") { stopSelf() })

        scrollRow.addView(btnRow)
        topBarContainer.addView(scrollRow)

        // Macro delay adjustment row
        val delayRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, 0)
            visibility = View.GONE
        }
        val delayLabel = TextView(this).apply {
            text = "Delay Macro: 60ms"
            setTextColor(Color.parseColor("#00E5FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.MONOSPACE
        }
        val delaySeek = SeekBar(this).apply {
            max = 490 // 10..500
            progress = 50
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val ms = 10 + p
                    delayLabel.text = "Delay Macro: ${ms}ms"
                    if (fromUser) {
                        val sel = selectedElementId ?: return
                        val cur = KeymapperRuntimeState.activeProfile.value.elements.firstOrNull { it.id == sel }
                        if (cur != null && cur.type == MappingElementType.COMBO_MACRO) {
                            KeymapperRuntimeState.addOrUpdateElement(cur.copy(macroDelayMs = ms))
                        }
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) = Unit
                override fun onStopTrackingTouch(sb: SeekBar?) = Unit
            })
        }
        delayRow.addView(delayLabel)
        delayRow.addView(delaySeek, LinearLayout.LayoutParams(dp(180), LinearLayout.LayoutParams.WRAP_CONTENT))
        macroDelayContainer = delayRow
        topBarContainer.addView(delayRow)

        // WASD resize row
        val wasdRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, 0)
            visibility = View.GONE
        }
        val wasdLabel = TextView(this).apply {
            text = "Raio WASD: 12%"
            setTextColor(Color.parseColor("#FF1E42"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.MONOSPACE
        }
        val wasdSeek = SeekBar(this).apply {
            max = 20 // 6%..26%
            progress = 6
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val frac = (6 + p) / 100f
                    wasdLabel.text = "Raio WASD: ${(frac * 100).roundToInt()}%"
                    if (fromUser) {
                        val sel = selectedElementId ?: return
                        val cur = KeymapperRuntimeState.activeProfile.value.elements.firstOrNull { it.id == sel }
                        if (cur != null && cur.type == MappingElementType.WASD_ANALOG) {
                            KeymapperRuntimeState.addOrUpdateElement(cur.copy(radiusFraction = frac))
                        }
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) = Unit
                override fun onStopTrackingTouch(sb: SeekBar?) = Unit
            })
        }
        wasdRow.addView(wasdLabel)
        wasdRow.addView(wasdSeek, LinearLayout.LayoutParams(dp(180), LinearLayout.LayoutParams.WRAP_CONTENT))
        wasdSizeContainer = wasdRow
        topBarContainer.addView(wasdRow)

        val topBarLp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.TOP
            setMargins(dp(12), dp(36), dp(12), 0)
        }
        root.addView(topBarContainer, topBarLp)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        editorCanvas = root
        editorParams = params
        runCatching { windowManager.addView(root, params) }
        rebuildMarkersLayer()
        root.requestFocus()
    }

    private fun createActionChip(title: String, bgHex: String = "#1D2028", onClick: () -> Unit): Button {
        return Button(this).apply {
            text = title
            isAllCaps = false
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = GradientDrawable().apply {
                setColor(Color.parseColor(bgHex))
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), Color.parseColor("#FF1E42"))
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                dp(36)
            ).apply {
                marginEnd = dp(6)
            }
            layoutParams = lp
            setOnClickListener { onClick() }
        }
    }

    private fun addTapMarker() {
        val id = "tap_${UUID.randomUUID().toString().take(6)}"
        val el = KeyMappingElement(
            id = id,
            type = MappingElementType.TAP,
            label = "TECLA?",
            keyCode = KeyEvent.KEYCODE_E,
            xFraction = 0.50f,
            yFraction = 0.50f
        )
        selectedElementId = id
        awaitingBindElementId = id
        awaitingAimToggleKey = false
        KeymapperRuntimeState.addOrUpdateElement(el)
        updateStatusBanner("Novo Tap criado! Pressione uma tecla física ou toque em Mouse Esq/Dir.")
    }

    private fun addWasdMarker() {
        val existing = KeymapperRuntimeState.activeProfile.value.elements.firstOrNull {
            it.type == MappingElementType.WASD_ANALOG
        }
        val el = existing ?: KeyMappingElement(
            id = "wasd_${UUID.randomUUID().toString().take(6)}",
            type = MappingElementType.WASD_ANALOG,
            label = "WASD",
            xFraction = 0.22f,
            yFraction = 0.66f,
            radiusFraction = 0.12f
        )
        selectedElementId = el.id
        KeymapperRuntimeState.addOrUpdateElement(el)
        wasdSizeContainer?.visibility = View.VISIBLE
        macroDelayContainer?.visibility = View.GONE
        updateStatusBanner("Analógico WASD ativo! Arraste na tela e ajuste o raio abaixo.")
    }

    private fun addMacroMarker() {
        val id = "macro_${UUID.randomUUID().toString().take(6)}"
        val el = KeyMappingElement(
            id = id,
            type = MappingElementType.COMBO_MACRO,
            label = "MACRO Q",
            keyCode = KeyEvent.KEYCODE_Q,
            xFraction = 0.45f,
            yFraction = 0.55f,
            secondaryXFraction = 0.62f,
            secondaryYFraction = 0.55f,
            macroDelayMs = 60
        )
        selectedElementId = id
        awaitingBindElementId = id
        KeymapperRuntimeState.addOrUpdateElement(el)
        macroDelayContainer?.visibility = View.VISIBLE
        wasdSizeContainer?.visibility = View.GONE
        updateStatusBanner("Macro 2-Toques criado! Pressione tecla e ajuste o delay (10-500ms).")
    }

    private fun bindSelectedToMouse(mouseButton: Int) {
        val sel = selectedElementId ?: KeymapperRuntimeState.activeProfile.value.elements.lastOrNull()?.id
        if (sel == null) {
            updateStatusBanner("Crie ou toque em um marcador primeiro.")
            return
        }
        val el = KeymapperRuntimeState.activeProfile.value.elements.firstOrNull { it.id == sel } ?: return
        KeymapperRuntimeState.addOrUpdateElement(
            el.copy(
                mouseButton = mouseButton,
                keyCode = KeyEvent.KEYCODE_UNKNOWN,
                label = KeyCodeFormatter.formatKeyOrMouse(0, mouseButton)
            )
        )
        awaitingBindElementId = null
        updateStatusBanner("Vinculado ao ${KeyCodeFormatter.formatKeyOrMouse(0, mouseButton)}")
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun rebuildMarkersLayer() {
        val root = editorCanvas ?: return
        // Remove previous marker views (keep index 0 = top bar)
        while (root.childCount > 1) {
            root.removeViewAt(1)
        }

        val (screenW, screenH) = getScreenDimensions()
        val minDim = minOf(screenW, screenH).toFloat()
        val elements = KeymapperRuntimeState.activeProfile.value.elements

        elements.forEach { el ->
            val markerSize = when (el.type) {
                MappingElementType.WASD_ANALOG -> (el.radiusFraction * minDim * 2f).roundToInt().coerceIn(dp(84), dp(220))
                MappingElementType.COMBO_MACRO -> dp(58)
                MappingElementType.TAP -> dp(52)
            }
            val marker = TextView(this).apply {
                text = when (el.type) {
                    MappingElementType.WASD_ANALOG -> "WASD"
                    MappingElementType.COMBO_MACRO -> "${el.label}\n${el.macroDelayMs}ms"
                    MappingElementType.TAP -> el.label
                }
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, if (el.type == MappingElementType.WASD_ANALOG) 12f else 10f)
                typeface = Typeface.MONOSPACE
                gravity = Gravity.CENTER
                val isSelected = el.id == selectedElementId
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(
                        when (el.type) {
                            MappingElementType.WASD_ANALOG -> Color.parseColor("#44FF1E42")
                            MappingElementType.COMBO_MACRO -> Color.parseColor("#CC0D2330")
                            MappingElementType.TAP -> Color.parseColor("#CC111216")
                        }
                    )
                    setStroke(
                        dp(if (isSelected) 3 else 2),
                        when (el.type) {
                            MappingElementType.COMBO_MACRO -> Color.parseColor("#00E5FF")
                            else -> Color.parseColor("#FF1E42")
                        }
                    )
                }
            }

            val lp = FrameLayout.LayoutParams(markerSize, markerSize).apply {
                gravity = Gravity.TOP or Gravity.START
                leftMargin = (el.xFraction * screenW - markerSize / 2f).roundToInt().coerceIn(0, screenW - markerSize)
                topMargin = (el.yFraction * screenH - markerSize / 2f).roundToInt().coerceIn(0, screenH - markerSize)
            }

            var startX = 0
            var startY = 0
            var rawDownX = 0f
            var rawDownY = 0f
            var dragged = false

            marker.setOnTouchListener { v, ev ->
                val curLp = v.layoutParams as FrameLayout.LayoutParams
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = curLp.leftMargin
                        startY = curLp.topMargin
                        rawDownX = ev.rawX
                        rawDownY = ev.rawY
                        dragged = false
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (ev.rawX - rawDownX).roundToInt()
                        val dy = (ev.rawY - rawDownY).roundToInt()
                        if (abs(dx) > 6 || abs(dy) > 6) dragged = true
                        curLp.leftMargin = (startX + dx).coerceIn(0, screenW - markerSize)
                        curLp.topMargin = (startY + dy).coerceIn(0, screenH - markerSize)
                        v.layoutParams = curLp
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (dragged) {
                            val newXf = ((curLp.leftMargin + markerSize / 2f) / screenW.toFloat()).coerceIn(0.05f, 0.95f)
                            val newYf = ((curLp.topMargin + markerSize / 2f) / screenH.toFloat()).coerceIn(0.08f, 0.95f)
                            KeymapperRuntimeState.addOrUpdateElement(el.copy(xFraction = newXf, yFraction = newYf))
                        } else {
                            selectedElementId = el.id
                            when (el.type) {
                                MappingElementType.WASD_ANALOG -> {
                                    wasdSizeContainer?.visibility = View.VISIBLE
                                    macroDelayContainer?.visibility = View.GONE
                                    awaitingBindElementId = null
                                    updateStatusBanner("WASD selecionado • Ajuste o raio ou arraste.")
                                }
                                MappingElementType.COMBO_MACRO -> {
                                    macroDelayContainer?.visibility = View.VISIBLE
                                    wasdSizeContainer?.visibility = View.GONE
                                    awaitingBindElementId = el.id
                                    updateStatusBanner("Macro '${el.label}' • Pressione tecla para reatribuir ou ajuste delay.")
                                }
                                MappingElementType.TAP -> {
                                    macroDelayContainer?.visibility = View.GONE
                                    wasdSizeContainer?.visibility = View.GONE
                                    awaitingBindElementId = el.id
                                    updateStatusBanner("Botão '${el.label}' • Pressione tecla física ou toque em Mouse Esq/Dir.")
                                }
                            }
                            rebuildMarkersLayer()
                        }
                        true
                    }
                    else -> false
                }
            }
            root.addView(marker, lp)
        }
    }

    private fun updateStatusBanner(message: String) {
        statusBanner?.text = message
    }

    private fun removeBubble() {
        bubbleView?.let { runCatching { windowManager.removeView(it) } }
        bubbleView = null
        bubbleParams = null
    }

    private fun removeEditor() {
        editorVisible = false
        editorCanvas?.let { runCatching { windowManager.removeView(it) } }
        editorCanvas = null
        editorParams = null
    }

    private fun getScreenDimensions(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = windowManager.currentWindowMetrics.bounds
            b.width().coerceAtLeast(100) to b.height().coerceAtLeast(100)
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(m)
            m.widthPixels.coerceAtLeast(100) to m.heightPixels.coerceAtLeast(100)
        }
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).roundToInt()
    }

    companion object {
        const val ACTION_OPEN_EDITOR = "com.example.action.OPEN_EDITOR"
        const val ACTION_STOP_OVERLAY = "com.example.action.STOP_OVERLAY"

        fun start(context: Context) {
            val intent = Intent(context, BotxOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, BotxOverlayService::class.java))
        }
    }
}
