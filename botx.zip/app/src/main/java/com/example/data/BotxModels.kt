package com.example.data

import android.view.KeyEvent
import android.view.MotionEvent
import kotlinx.serialization.Serializable

enum class BotxTab(val label: String) {
    PAINEL("Painel"),
    MAPEADOR("Mapeador"),
    MOBILADOR("Mobilador"),
    DESEMPENHO("Desempenho"),
    SISTEMA("Sistema")
}

enum class EngineMode(val badgeLabel: String) {
    SHIZUKU("SHIZUKU ATIVO"),
    ACESSIBILIDADE("ACESSIBILIDADE ATIVA"),
    NATIVO("MODO NATIVO")
}

@Serializable
enum class MappingElementType {
    TAP,
    WASD_ANALOG,
    COMBO_MACRO
}

@Serializable
data class KeyMappingElement(
    val id: String,
    val type: MappingElementType,
    val label: String,
    val keyCode: Int = KeyEvent.KEYCODE_UNKNOWN,
    val mouseButton: Int = 0, // 0 = keyboard, MotionEvent.BUTTON_PRIMARY (1), BUTTON_SECONDARY (2)
    val xFraction: Float = 0.5f,
    val yFraction: Float = 0.5f,
    val radiusFraction: Float = 0.11f, // Used for WASD Analog
    val secondaryXFraction: Float = 0.62f, // Used for Combo/Macro 2nd tap
    val secondaryYFraction: Float = 0.5f,
    val macroDelayMs: Int = 60 // 10ms..500ms
)

@Serializable
data class KeymapProfile(
    val id: String,
    val name: String,
    val packageName: String = "",
    val sensitivityX: Float = 1.25f,
    val sensitivityY: Float = 1.15f,
    val dragSmoothing: Float = 0.35f,
    val aimToggleKeyCode: Int = KeyEvent.KEYCODE_F,
    val elements: List<KeyMappingElement> = emptyList()
)

data class HardwareTelemetry(
    val deviceModel: String = "",
    val manufacturer: String = "",
    val androidVersion: String = "",
    val apiLevel: Int = 0,
    val cpuCores: Int = 0,
    val cpuAbi: String = "",
    val totalRamMb: Long = 0L,
    val availableRamMb: Long = 0L,
    val usedRamPercent: Int = 0,
    val batteryPercent: Int = 0,
    val batteryTempC: Float = 0f,
    val batteryVoltageMv: Int = 0,
    val isCharging: Boolean = false,
    val refreshRateHz: Int = 60,
    val availableRefreshRatesHz: List<Int> = listOf(60),
    val currentDpi: Int = 420,
    val defaultDpi: Int = 420
)

data class PeripheralDevice(
    val id: Int,
    val name: String,
    val descriptor: String,
    val isMouse: Boolean,
    val isKeyboard: Boolean,
    val vendorId: Int,
    val productId: Int
)

data class InstalledAppInfo(
    val packageName: String,
    val label: String,
    val isGame: Boolean,
    val isSystemApp: Boolean,
    val isEnabled: Boolean
)

data class PingSample(
    val timestampMs: Long,
    val dns1Ms: Int,
    val dns8Ms: Int,
    val jitterMs: Int,
    val packetLoss: Boolean
)

data class MobiladorSettingsState(
    val pointerSpeed: Int = 0, // -7..+7
    val longPressTimeoutMs: Int = 400,
    val touchSensitivity: Boolean = false,
    val landscapeLocked: Boolean = false,
    val immersiveMode: Boolean = false,
    val customDpiInput: String = "",
    val dpiRevertSecondsRemaining: Int = 0
)

data class PerformanceState(
    val turboActive: Boolean = false,
    val zeroAnimationsActive: Boolean = false,
    val maxRefreshRateForced: Boolean = false,
    val dndActive: Boolean = false,
    val thermalShieldEnabled: Boolean = false,
    val thermalShieldTriggered: Boolean = false,
    val hapticDisabled: Boolean = false,
    val lastFreedRamMb: Long = 0L,
    val lastAotStatus: String = ""
)

object KeyCodeFormatter {
    fun formatKeyOrMouse(keyCode: Int, mouseButton: Int): String {
        return when (mouseButton) {
            MotionEvent.BUTTON_PRIMARY -> "MOUSE ESQ"
            MotionEvent.BUTTON_SECONDARY -> "MOUSE DIR"
            MotionEvent.BUTTON_TERTIARY -> "MOUSE MEIO"
            else -> {
                val raw = KeyEvent.keyCodeToString(keyCode)
                raw.removePrefix("KEYCODE_").replace("_", " ")
            }
        }
    }
}
