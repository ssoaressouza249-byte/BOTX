package com.example.data

import android.content.Context
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json

private val Context.botxDataStore: DataStore<Preferences> by preferencesDataStore(name = "botx_prefs")

class ProfileRepository(private val context: Context) {

    private val json = Json {
        ignoreUnknownKeys = true
        prettyPrint = true
        encodeDefaults = true
    }

    private object Keys {
        val PROFILES_JSON = stringPreferencesKey("profiles_json")
        val ACTIVE_PROFILE_ID = stringPreferencesKey("active_profile_id")
        val USE_SHIZUKU_INPUT = booleanPreferencesKey("use_shizuku_input")
        val THERMAL_SHIELD = booleanPreferencesKey("thermal_shield_enabled")
        val GAME_PROFILE_MAP = stringPreferencesKey("game_profile_map")
    }

    val profilesFlow: Flow<List<KeymapProfile>> = context.botxDataStore.data.map { prefs ->
        val raw = prefs[Keys.PROFILES_JSON]
        if (raw.isNullOrBlank()) {
            defaultProfiles()
        } else {
            runCatching { json.decodeFromString<List<KeymapProfile>>(raw) }
                .getOrElse { defaultProfiles() }
        }
    }

    val activeProfileIdFlow: Flow<String> = context.botxDataStore.data.map { prefs ->
        prefs[Keys.ACTIVE_PROFILE_ID] ?: "fps_default"
    }

    val useShizukuInputFlow: Flow<Boolean> = context.botxDataStore.data.map { prefs ->
        prefs[Keys.USE_SHIZUKU_INPUT] ?: false
    }

    val thermalShieldFlow: Flow<Boolean> = context.botxDataStore.data.map { prefs ->
        prefs[Keys.THERMAL_SHIELD] ?: false
    }

    val gameProfileMapFlow: Flow<Map<String, String>> = context.botxDataStore.data.map { prefs ->
        val raw = prefs[Keys.GAME_PROFILE_MAP]
        if (raw.isNullOrBlank()) emptyMap()
        else runCatching { json.decodeFromString<Map<String, String>>(raw) }.getOrElse { emptyMap() }
    }

    suspend fun saveProfiles(profiles: List<KeymapProfile>) {
        val serialized = json.encodeToString(profiles)
        context.botxDataStore.edit { prefs ->
            prefs[Keys.PROFILES_JSON] = serialized
        }
    }

    suspend fun setActiveProfileId(profileId: String) {
        context.botxDataStore.edit { prefs ->
            prefs[Keys.ACTIVE_PROFILE_ID] = profileId
        }
    }

    suspend fun setUseShizukuInput(enabled: Boolean) {
        context.botxDataStore.edit { prefs ->
            prefs[Keys.USE_SHIZUKU_INPUT] = enabled
        }
    }

    suspend fun setThermalShield(enabled: Boolean) {
        context.botxDataStore.edit { prefs ->
            prefs[Keys.THERMAL_SHIELD] = enabled
        }
    }

    suspend fun bindGameToProfile(packageName: String, profileId: String) {
        context.botxDataStore.edit { prefs ->
            val current = prefs[Keys.GAME_PROFILE_MAP]?.let {
                runCatching { json.decodeFromString<Map<String, String>>(it) }.getOrNull()
            } ?: emptyMap()
            val updated = current.toMutableMap().apply { put(packageName, profileId) }
            prefs[Keys.GAME_PROFILE_MAP] = json.encodeToString(updated)
        }
    }

    fun exportProfileJson(profile: KeymapProfile): String = json.encodeToString(profile)

    companion object {
        fun defaultProfiles(): List<KeymapProfile> = listOf(
            KeymapProfile(
                id = "fps_default",
                name = "Perfil Padrão FPS",
                sensitivityX = 1.30f,
                sensitivityY = 1.10f,
                dragSmoothing = 0.25f,
                aimToggleKeyCode = KeyEvent.KEYCODE_F,
                elements = listOf(
                    KeyMappingElement(
                        id = "wasd_fps",
                        type = MappingElementType.WASD_ANALOG,
                        label = "WASD",
                        xFraction = 0.18f,
                        yFraction = 0.68f,
                        radiusFraction = 0.12f
                    ),
                    KeyMappingElement(
                        id = "fire_fps",
                        type = MappingElementType.TAP,
                        label = "ATIRAR",
                        mouseButton = MotionEvent.BUTTON_PRIMARY,
                        xFraction = 0.84f,
                        yFraction = 0.66f
                    ),
                    KeyMappingElement(
                        id = "ads_fps",
                        type = MappingElementType.TAP,
                        label = "MIRA",
                        mouseButton = MotionEvent.BUTTON_SECONDARY,
                        xFraction = 0.88f,
                        yFraction = 0.44f
                    ),
                    KeyMappingElement(
                        id = "reload_fps",
                        type = MappingElementType.TAP,
                        label = "R",
                        keyCode = KeyEvent.KEYCODE_R,
                        xFraction = 0.72f,
                        yFraction = 0.78f
                    ),
                    KeyMappingElement(
                        id = "jump_fps",
                        type = MappingElementType.TAP,
                        label = "ESPAÇO",
                        keyCode = KeyEvent.KEYCODE_SPACE,
                        xFraction = 0.90f,
                        yFraction = 0.80f
                    )
                )
            ),
            KeymapProfile(
                id = "battle_royale",
                name = "Battle Royale",
                sensitivityX = 1.55f,
                sensitivityY = 1.35f,
                dragSmoothing = 0.30f,
                aimToggleKeyCode = KeyEvent.KEYCODE_CTRL_LEFT,
                elements = listOf(
                    KeyMappingElement(
                        id = "wasd_br",
                        type = MappingElementType.WASD_ANALOG,
                        label = "WASD",
                        xFraction = 0.17f,
                        yFraction = 0.70f,
                        radiusFraction = 0.13f
                    ),
                    KeyMappingElement(
                        id = "fire_br",
                        type = MappingElementType.TAP,
                        label = "TIRO",
                        mouseButton = MotionEvent.BUTTON_PRIMARY,
                        xFraction = 0.84f,
                        yFraction = 0.68f
                    ),
                    KeyMappingElement(
                        id = "gel_combo_br",
                        type = MappingElementType.COMBO_MACRO,
                        label = "MACRO Q",
                        keyCode = KeyEvent.KEYCODE_Q,
                        xFraction = 0.76f,
                        yFraction = 0.56f,
                        secondaryXFraction = 0.84f,
                        secondaryYFraction = 0.68f,
                        macroDelayMs = 45
                    ),
                    KeyMappingElement(
                        id = "crouch_br",
                        type = MappingElementType.TAP,
                        label = "C",
                        keyCode = KeyEvent.KEYCODE_C,
                        xFraction = 0.79f,
                        yFraction = 0.82f
                    )
                )
            )
        )
    }
}
