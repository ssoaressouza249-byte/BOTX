package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val BotxDarkColorScheme = darkColorScheme(
    primary = BotxNeonRed,
    onPrimary = BotxTextPrimary,
    primaryContainer = BotxNeonRedDark,
    onPrimaryContainer = BotxTextPrimary,
    secondary = BotxCyan,
    onSecondary = BotxObsidianBg,
    secondaryContainer = BotxCardElevated,
    onSecondaryContainer = BotxTextPrimary,
    tertiary = BotxEmerald,
    onTertiary = BotxObsidianBg,
    background = BotxObsidianBg,
    onBackground = BotxTextPrimary,
    surface = BotxCardSurface,
    onSurface = BotxTextPrimary,
    surfaceVariant = BotxCardElevated,
    onSurfaceVariant = BotxTextSecondary,
    outline = BotxBorderSubtle,
    outlineVariant = BotxBorderActive,
    error = BotxNeonRed,
    onError = BotxTextPrimary
)

val BotxShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp)
)

@Composable
fun BotxTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = BotxDarkColorScheme,
        typography = BotxTypography,
        shapes = BotxShapes,
        content = content
    )
}
