package com.example.ui.screens

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DoNotDisturbOn
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.HardwareTelemetry
import com.example.data.InstalledAppInfo
import com.example.data.PerformanceState
import com.example.ui.components.BotxCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.TacticalToggleRow
import com.example.ui.theme.BotxAmber
import com.example.ui.theme.BotxBorderSubtle
import com.example.ui.theme.BotxCardElevated
import com.example.ui.theme.BotxCyan
import com.example.ui.theme.BotxEmerald
import com.example.ui.theme.BotxNeonRed
import com.example.ui.theme.BotxTextPrimary
import com.example.ui.theme.BotxTextSecondary

@Composable
fun DesempenhoScreen(
    telemetry: HardwareTelemetry,
    state: PerformanceState,
    installedApps: List<InstalledAppInfo>,
    isShizukuReady: Boolean,
    hasDndPermission: Boolean,
    onToggleZeroAnimations: (Boolean) -> Unit,
    onToggleMaxRefreshRate: (Activity?, Boolean) -> Unit,
    onRunRamCleanup: () -> Unit,
    onRunAotCompile: (InstalledAppInfo) -> Unit,
    onToggleDnd: (Boolean) -> Unit,
    onToggleThermalShield: (Boolean) -> Unit,
    onToggleDisableHaptics: (Boolean) -> Unit
) {
    val activity = LocalContext.current as? Activity
    var selectedAotApp by remember(installedApps) {
        mutableStateOf(installedApps.firstOrNull { it.isGame } ?: installedApps.firstOrNull())
    }
    var showAppPicker by remember { mutableStateOf(false) }

    val maxSupportedHz = telemetry.availableRefreshRatesHz.maxOrNull() ?: telemetry.refreshRateHz

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Estabilidade de CPU, GPU e Tela",
                subtitle = "Redução de latência e sobrecarga de renderização",
                icon = Icons.Default.Speed
            )
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                TacticalToggleRow(
                    title = "Zero Animação de Sistema",
                    subtitle = if (isShizukuReady) "Zera Window/Transition/Animator Scale via Shizuku"
                    else "Requer Shizuku para escalas globais",
                    icon = Icons.Default.Animation,
                    checked = state.zeroAnimationsActive,
                    testTag = "zero_anim_switch",
                    onCheckedChange = onToggleZeroAnimations
                )
                TacticalToggleRow(
                    title = "Forçar Taxa Máxima (${maxSupportedHz}Hz)",
                    subtitle = "Detectadas: ${telemetry.availableRefreshRatesHz.joinToString("Hz, ")}Hz",
                    icon = Icons.Default.Refresh,
                    checked = state.maxRefreshRateForced,
                    testTag = "max_hz_switch",
                    onCheckedChange = { onToggleMaxRefreshRate(activity, it) }
                )
                TacticalToggleRow(
                    title = "Modo Sem Distrações (Não Perturbe)",
                    subtitle = if (hasDndPermission) "Bloqueia chamadas e banners via NotificationManager"
                    else "Toque para conceder ACCESS_NOTIFICATION_POLICY",
                    icon = Icons.Default.DoNotDisturbOn,
                    checked = state.dndActive,
                    testTag = "dnd_switch",
                    onCheckedChange = onToggleDnd
                )
                TacticalToggleRow(
                    title = "Escudo Térmico Automático (>39°C)",
                    subtitle = if (state.thermalShieldTriggered) "ATIVO AGORA: Brilho reduzido (${telemetry.batteryTempC}°C)"
                    else "Reduz brilho via WRITE_SETTINGS se passar de 39°C",
                    icon = Icons.Default.Thermostat,
                    checked = state.thermalShieldEnabled,
                    testTag = "thermal_shield_switch",
                    onCheckedChange = onToggleThermalShield
                )
                TacticalToggleRow(
                    title = "Desativar Vibração Tátil",
                    subtitle = "Desliga resposta háptica do sistema durante a sessão",
                    icon = Icons.Default.Vibration,
                    checked = state.hapticDisabled,
                    testTag = "disable_haptics_switch",
                    onCheckedChange = onToggleDisableHaptics
                )
            }
        }

        // Deep RAM Cleanup
        item {
            SectionHeader(
                title = "Limpeza Profunda de RAM Ociosa",
                subtitle = "Encerra processos em segundo plano via ActivityManager",
                icon = Icons.Default.Memory
            )
            Spacer(modifier = Modifier.height(8.dp))
            BotxCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "RAM Livre Atual: ${telemetry.availableRamMb} MB",
                            style = MaterialTheme.typography.labelLarge,
                            color = BotxCyan
                        )
                        if (state.lastFreedRamMb > 0) {
                            Text(
                                text = "Última limpeza liberou: ${state.lastFreedRamMb} MB",
                                style = MaterialTheme.typography.labelSmall,
                                color = BotxEmerald
                            )
                        }
                    }
                    Button(
                        onClick = onRunRamCleanup,
                        modifier = Modifier.testTag("ram_cleanup_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = BotxNeonRed),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.CleaningServices, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("LIMPAR RAM", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }

        // Compilação AOT de Performance (Speed Profile)
        item {
            SectionHeader(
                title = "Compilação AOT (Speed Profile)",
                subtitle = "Executa 'cmd package compile -m speed -f' via Shizuku",
                icon = Icons.Default.FlashOn
            )
            Spacer(modifier = Modifier.height(8.dp))
            BotxCard(highlighted = state.lastAotStatus.isNotEmpty()) {
                val target = selectedAotApp
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(BotxCardElevated)
                        .border(1.dp, BotxBorderSubtle, RoundedCornerShape(8.dp))
                        .clickable { showAppPicker = true }
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = target?.label ?: "Selecionar Jogo / App",
                            style = MaterialTheme.typography.titleSmall,
                            color = BotxTextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = target?.packageName ?: "Toque para escolher o pacote",
                            style = MaterialTheme.typography.labelSmall,
                            color = BotxTextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        text = "ALTERAR",
                        style = MaterialTheme.typography.labelSmall,
                        color = BotxNeonRed
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = { target?.let(onRunAotCompile) },
                    enabled = target != null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("aot_compile_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = BotxNeonRed),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = if (isShizukuReady) "COMPILAR SPEED PROFILE (AOT)"
                        else "REQUER SHIZUKU ATIVO",
                        style = MaterialTheme.typography.labelLarge
                    )
                }

                if (state.lastAotStatus.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = state.lastAotStatus,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (state.lastAotStatus.contains("concluído")) BotxEmerald else BotxAmber
                    )
                }
            }
        }
    }

    if (showAppPicker) {
        AlertDialog(
            onDismissRequest = { showAppPicker = false },
            title = { Text("Escolher App para AOT Speed", style = MaterialTheme.typography.titleMedium) },
            text = {
                LazyColumn(modifier = Modifier.height(280.dp)) {
                    items(installedApps.size) { idx ->
                        val app = installedApps[idx]
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedAotApp = app
                                    showAppPicker = false
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(app.label, style = MaterialTheme.typography.titleSmall, color = BotxTextPrimary)
                                Text(app.packageName, style = MaterialTheme.typography.labelSmall, color = BotxTextSecondary)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAppPicker = false }) {
                    Text("Fechar", color = BotxNeonRed)
                }
            }
        )
    }
}
