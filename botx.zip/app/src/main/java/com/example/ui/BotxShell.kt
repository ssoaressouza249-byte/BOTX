package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.Gamepad
import androidx.compose.material.icons.outlined.Mouse
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.BotxTab
import com.example.system.KeymapperRuntimeState
import com.example.ui.components.BotxTopBar
import com.example.ui.screens.DesempenhoScreen
import com.example.ui.screens.MapeadorScreen
import com.example.ui.screens.MobiladorScreen
import com.example.ui.screens.PainelScreen
import com.example.ui.screens.SistemaScreen
import com.example.ui.theme.BotxCardSurface
import com.example.ui.theme.BotxNeonRed
import com.example.ui.theme.BotxNeonRedGlow
import com.example.ui.theme.BotxObsidianBg
import com.example.ui.theme.BotxTextMuted
import com.example.ui.theme.BotxTextPrimary

@Composable
fun BotxAppRoot(vm: BotxViewModel = viewModel()) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val currentTab by vm.currentTab.collectAsStateWithLifecycle()
    val telemetry by vm.telemetry.collectAsStateWithLifecycle()
    val ramHistory by vm.ramHistory.collectAsStateWithLifecycle()
    val tempHistory by vm.tempHistory.collectAsStateWithLifecycle()
    val peripherals by vm.peripherals.collectAsStateWithLifecycle()
    val installedApps by vm.installedApps.collectAsStateWithLifecycle()
    val profiles by vm.profiles.collectAsStateWithLifecycle()
    val activeProfile by vm.activeProfile.collectAsStateWithLifecycle()
    val gameProfileMap by vm.gameProfileMap.collectAsStateWithLifecycle()
    val mobiladorState by vm.mobiladorState.collectAsStateWithLifecycle()
    val performanceState by vm.performanceState.collectAsStateWithLifecycle()
    val pingHistory by vm.pingHistory.collectAsStateWithLifecycle()
    val pingMonitorRunning by vm.pingMonitorRunning.collectAsStateWithLifecycle()
    val engineMode by vm.engineMode.collectAsStateWithLifecycle()
    val isShizukuReady by vm.isShizukuReady.collectAsStateWithLifecycle()
    val hasOverlayPermission by vm.hasOverlayPermission.collectAsStateWithLifecycle()
    val hasAccessibilityEnabled by vm.hasAccessibilityEnabled.collectAsStateWithLifecycle()
    val hasWriteSettings by vm.hasWriteSettings.collectAsStateWithLifecycle()
    val hasDndPermission by vm.hasDndPermission.collectAsStateWithLifecycle()
    val statusMessage by vm.statusMessage.collectAsStateWithLifecycle()

    val isOverlayRunning by KeymapperRuntimeState.isOverlayRunning.collectAsStateWithLifecycle()
    val isAimModeLocked by KeymapperRuntimeState.isAimModeLocked.collectAsStateWithLifecycle()
    val useShizukuInjection by KeymapperRuntimeState.useShizukuInjection.collectAsStateWithLifecycle()
    val lastInputLabel by KeymapperRuntimeState.lastInputEventLabel.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            vm.toggleFloatingBubble()
        } else {
            vm.postStatus("Permissão de notificação negada para o serviço em primeiro plano.")
        }
    }

    LaunchedEffect(statusMessage) {
        val msg = statusMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            vm.clearStatusMessage()
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                vm.refreshPermissionsAndHardware()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    BackHandler(enabled = currentTab != BotxTab.PAINEL) {
        vm.selectTab(BotxTab.PAINEL)
    }

    Scaffold(
        containerColor = BotxObsidianBg,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            BotxTopBar(
                telemetry = telemetry,
                engineMode = engineMode
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = BotxCardSurface,
                tonalElevation = 0.dp,
                windowInsets = WindowInsets.navigationBars
            ) {
                BotxTab.entries.forEach { tab ->
                    val selected = tab == currentTab
                    val selectedIcon = when (tab) {
                        BotxTab.PAINEL -> Icons.Filled.Dashboard
                        BotxTab.MAPEADOR -> Icons.Filled.Gamepad
                        BotxTab.MOBILADOR -> Icons.Filled.Mouse
                        BotxTab.DESEMPENHO -> Icons.Filled.Speed
                        BotxTab.SISTEMA -> Icons.Filled.Dns
                    }
                    val unselectedIcon = when (tab) {
                        BotxTab.PAINEL -> Icons.Outlined.Dashboard
                        BotxTab.MAPEADOR -> Icons.Outlined.Gamepad
                        BotxTab.MOBILADOR -> Icons.Outlined.Mouse
                        BotxTab.DESEMPENHO -> Icons.Outlined.Speed
                        BotxTab.SISTEMA -> Icons.Outlined.Dns
                    }
                    NavigationBarItem(
                        selected = selected,
                        onClick = { vm.selectTab(tab) },
                        modifier = Modifier.testTag("nav_${tab.name.lowercase()}"),
                        icon = {
                            Icon(
                                imageVector = if (selected) selectedIcon else unselectedIcon,
                                contentDescription = tab.label
                            )
                        },
                        label = {
                            Text(
                                text = tab.label,
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BotxNeonRed,
                            selectedTextColor = BotxTextPrimary,
                            indicatorColor = BotxNeonRedGlow,
                            unselectedIconColor = BotxTextMuted,
                            unselectedTextColor = BotxTextMuted
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                BotxTab.PAINEL -> PainelScreen(
                    telemetry = telemetry,
                    ramHistory = ramHistory,
                    tempHistory = tempHistory,
                    peripherals = peripherals,
                    installedApps = installedApps,
                    activeProfile = activeProfile,
                    performanceState = performanceState,
                    gameProfileMap = gameProfileMap,
                    allProfiles = profiles,
                    onActivateTurbo = vm::activateTurboMode,
                    onDeactivateTurbo = vm::deactivateTurboMode,
                    onRefreshPeripherals = vm::refreshPeripherals,
                    onRefreshApps = vm::refreshInstalledApps,
                    onLaunchGame = vm::launchGameWithProfile
                )
                BotxTab.MAPEADOR -> MapeadorScreen(
                    hasOverlayPermission = hasOverlayPermission,
                    hasAccessibilityEnabled = hasAccessibilityEnabled,
                    isShizukuReady = isShizukuReady,
                    useShizukuInjection = useShizukuInjection,
                    isOverlayRunning = isOverlayRunning,
                    isAimModeLocked = isAimModeLocked,
                    lastInputLabel = lastInputLabel,
                    profiles = profiles,
                    activeProfile = activeProfile,
                    installedApps = installedApps,
                    onRequestOverlay = vm::requestOverlayPermission,
                    onRequestAccessibility = vm::requestAccessibilitySettings,
                    onRequestShizuku = vm::requestShizukuPermission,
                    onToggleShizukuInput = vm::setUseShizukuInput,
                    onToggleFloatingBubble = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                            ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.POST_NOTIFICATIONS
                            ) != PackageManager.PERMISSION_GRANTED
                        ) {
                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            vm.toggleFloatingBubble()
                        }
                    },
                    onSelectProfile = vm::selectProfile,
                    onCreateProfile = vm::createProfile,
                    onDeleteProfile = vm::deleteProfile,
                    onBindGameToProfile = vm::bindGameToCurrentProfile,
                    onUpdateSensitivity = vm::updateActiveProfileSensitivity,
                    onUpdateAimToggleKey = vm::updateAimToggleKey,
                    onAddOrUpdateElement = vm::addOrUpdateElementInActiveProfile,
                    onRemoveElement = vm::removeElementFromActiveProfile,
                    exportProfileJson = vm::exportActiveProfileJson
                )
                BotxTab.MOBILADOR -> MobiladorScreen(
                    telemetry = telemetry,
                    state = mobiladorState,
                    isShizukuReady = isShizukuReady,
                    hasWriteSettings = hasWriteSettings,
                    onRequestWriteSettings = vm::requestWriteSettingsPermission,
                    onDpiInputChange = vm::updateCustomDpiInput,
                    onApplyCustomDpi = vm::applyCustomDpiWithSafetyTimer,
                    onConfirmCustomDpi = vm::confirmCustomDpi,
                    onRevertCustomDpi = vm::revertCustomDpi,
                    onPointerSpeedChange = vm::setPointerSpeed,
                    onLongPressPresetSelect = vm::setLongPressPreset,
                    onToggleTouchSensitivity = vm::toggleTouchSensitivity,
                    onToggleLandscapeLock = vm::toggleLandscapeLock,
                    onToggleImmersiveMode = vm::toggleImmersiveMode
                )
                BotxTab.DESEMPENHO -> DesempenhoScreen(
                    telemetry = telemetry,
                    state = performanceState,
                    installedApps = installedApps,
                    isShizukuReady = isShizukuReady,
                    hasDndPermission = hasDndPermission,
                    onToggleZeroAnimations = vm::toggleZeroAnimations,
                    onToggleMaxRefreshRate = vm::toggleMaxRefreshRate,
                    onRunRamCleanup = vm::runDeepRamCleanup,
                    onRunAotCompile = vm::runAotCompileForApp,
                    onToggleDnd = vm::toggleDoNotDisturb,
                    onToggleThermalShield = vm::toggleThermalShield,
                    onToggleDisableHaptics = vm::toggleDisableHaptics
                )
                BotxTab.SISTEMA -> SistemaScreen(
                    pingHistory = pingHistory,
                    pingMonitorRunning = pingMonitorRunning,
                    installedApps = installedApps,
                    isShizukuReady = isShizukuReady,
                    backgroundRestrictionStatus = vm.getBackgroundDataStatus(),
                    onTogglePingMonitor = vm::togglePingMonitor,
                    onDisableCaptivePortal = vm::disableCaptivePortalChecks,
                    onOpenBackgroundDataSettings = vm::openBackgroundDataRestrictions,
                    onForceStopApp = vm::forceStopApp,
                    onToggleFreezeApp = vm::toggleFreezeApp
                )
            }
        }
    }
}
