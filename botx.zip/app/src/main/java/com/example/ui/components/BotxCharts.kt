package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.BotxBorderSubtle
import com.example.ui.theme.BotxCardSurface
import com.example.ui.theme.BotxCyan
import com.example.ui.theme.BotxNeonRed
import com.example.ui.theme.BotxTextMuted
import com.example.ui.theme.BotxTextSecondary

@Composable
fun LiveMetricLineChart(
    title: String,
    currentValueText: String,
    samples: List<Float>,
    minVal: Float,
    maxVal: Float,
    lineColor: Color = BotxNeonRed,
    secondarySamples: List<Float>? = null,
    secondaryColor: Color = BotxCyan,
    chartHeight: Dp = 96.dp,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(BotxCardSurface)
            .border(1.dp, BotxBorderSubtle, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = BotxTextSecondary
            )
            Text(
                text = currentValueText,
                style = MaterialTheme.typography.labelLarge,
                color = lineColor
            )
        }
        Spacer(modifier = Modifier.height(10.dp))

        if (samples.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(chartHeight),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Coletando amostras ao vivo...",
                    style = MaterialTheme.typography.labelSmall,
                    color = BotxTextMuted
                )
            }
        } else {
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(chartHeight)
            ) {
                val w = size.width
                val h = size.height
                val span = (maxVal - minVal).coerceAtLeast(1f)

                // Horizontal tactical grid lines
                for (i in 0..3) {
                    val y = h * (i / 3f)
                    drawLine(
                        color = BotxBorderSubtle,
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 1.dp.toPx()
                    )
                }

                fun drawSeries(values: List<Float>, color: Color, fillArea: Boolean) {
                    if (values.isEmpty()) return
                    val pts = if (values.size == 1) listOf(values.first(), values.first()) else values
                    val stepX = w / (pts.size - 1).coerceAtLeast(1)
                    val linePath = Path()
                    val areaPath = Path()

                    pts.forEachIndexed { index, value ->
                        val norm = ((value - minVal) / span).coerceIn(0f, 1f)
                        val x = index * stepX
                        val y = h - (norm * (h - 6.dp.toPx())) - 3.dp.toPx()
                        if (index == 0) {
                            linePath.moveTo(x, y)
                            areaPath.moveTo(x, h)
                            areaPath.lineTo(x, y)
                        } else {
                            linePath.lineTo(x, y)
                            areaPath.lineTo(x, y)
                        }
                    }
                    areaPath.lineTo(w, h)
                    areaPath.close()

                    if (fillArea) {
                        drawPath(
                            path = areaPath,
                            brush = Brush.verticalGradient(
                                colors = listOf(color.copy(alpha = 0.28f), Color.Transparent)
                            )
                        )
                    }
                    drawPath(
                        path = linePath,
                        color = color,
                        style = Stroke(
                            width = 2.2.dp.toPx(),
                            cap = StrokeCap.Round,
                            join = StrokeJoin.Round
                        )
                    )
                }

                drawSeries(samples, lineColor, fillArea = true)
                if (!secondarySamples.isNullOrEmpty()) {
                    drawSeries(secondarySamples, secondaryColor, fillArea = false)
                }
            }
        }
    }
}
