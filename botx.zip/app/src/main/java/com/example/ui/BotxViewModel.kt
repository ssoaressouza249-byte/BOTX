package com.example.ui

import android.app.Activity
import android.app.Application
import android.content.Context
import android.hardware.input.InputManager
import android.view.KeyEvent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.BotxTab
import com.example.data.EngineMode
import com.example.data.HardwareTelemetry
import com.example.data.InstalledAppInfo
import com.example.data.KeyMappingElement
import com.example.data.KeymapProfile
import com.example.data.MappingElementType
import com.example.data.MobiladorSettingsState
import com.example.data.PerformanceState
import com.example.data.PeripheralDevice
import com.example.data.PingSample
import com.example.data.ProfileRepository
import com.example.service.BotxOverlayService
import com.example.system.KeymapperRuntimeState
import com.example.system.ShizukuBridge
import com.example.system.SystemOptimizerEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class BotxViewModel(application: Application) : AndroidViewModel(application) {

    private val engine = SystemOptimizerEngine(application)
    private val repository = ProfileRepository(application)
    private val inputManager = application.getSystemService(Context.INPUT_SERVICE) as InputManager

    private val _currentTab = MutableStateFlow(BotxTab.PAINEL)
    val currentTab: StateFlow<BotxTab> = _currentTab.asStateFlow()

    private val _telemetry = MutableStateFlow(engine.readHardwareTelemetry())
    val telemetry: StateFlow<HardwareTelemetry> = _telemetry.asStateFlow()

    private val _ramHistory = MutableStateFlow(listOf(engine.readHardwareTelemetry().usedRamPercent.toFloat()))
    val ramHistory: StateFlow<List<Float>> = _ramHistory.asStateFlow()

    private val _tempHistory = MutableStateFlow(listOf(engine.readHardwareTelemetry().batteryTempC))
    val tempHistory: StateFlow<List<Float>> = _tempHistory.asStateFlow()

    private val _peripherals = MutableStateFlow(engine.detectConnectedPeripherals())
    val peripherals: StateFlow<List<PeripheralDevice>> = _peripherals.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _profiles = MutableStateFlow(ProfileRepository.defaultProfiles())
    val profiles: StateFlow<List<KeymapProfile>> = _profiles.asStateFlow()

    private val _activeProfileId = MutableStateFlow("fps_default")
    val activeProfileId: StateFlow<String> = _activeProfileId.asStateFlow()

    private val _gameProfileMap = MutableStateFlow<Map<String, String>>(emptyMap())
    val gameProfileMap: StateFlow<Map<String, String>> = _gameProfileMap.asStateFlow()

    private val _mobiladorState = MutableStateFlow(
        MobiladorSettingsState(
            pointerSpeed = engine.readPointerSpeed(),
            longPressTimeoutMs = engine.readLongPressTimeout(),
            customDpiInput = engine.readHardwareTelemetry().currentDpi.toString()
        )
    )
    val mobiladorState: StateFlow<MobiladorSettingsState> = _mobiladorState.asStateFlow()

    private val _performanceState = MutableStateFlow(PerformanceState())
    val performanceState: StateFlow<PerformanceState> = _performanceState.asStateFlow()

    private val _pingHistory = MutableStateFlow<List<PingSample>>(emptyList())
    val pingHistory: StateFlow<List<PingSample>> = _pingHistory.asStateFlow()

    private val _pingMonitorRunning = MutableStateFlow(true)
    val pingMonitorRunning: StateFlow<Boolean> = _pingMonitorRunning.asStateFlow()

    private val _hasOverlayPermission = MutableStateFlow(engine.hasOverlayPermission())
    val hasOverlayPermission: StateFlow<Boolean> = _hasOverlayPermission.asStateFlow()

    private val _hasAccessibilityEnabled = MutableStateFlow(engine.isAccessibilityEnabled())
    val hasAccessibilityEnabled: StateFlow<Boolean> = _hasAccessibilityEnabled.asStateFlow()

    private val _hasWriteSettings = MutableStateFlow(engine.hasWriteSettingsPermission())
    val hasWriteSettings: StateFlow<Boolean> = _hasWriteSettings.asStateFlow()

    private val _hasDndPermission = MutableStateFlow(engine.hasDndPermission())
    val hasDndPermission: StateFlow<Boolean> = _hasDndPermission.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    val isShizukuReady: StateFlow<Boolean> = combine(
        ShizukuBridge.isBinderAlive,
        ShizukuBridge.isPermissionGranted
    ) { alive, granted -> alive && granted }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ShizukuBridge.isReady())

    val engineMode: StateFlow<EngineMode> = combine(
        isShizukuReady,
        _hasAccessibilityEnabled,
        KeymapperRuntimeState.isAccessibilityConnected
    ) { shizuku, accSetting, accConnected ->
        when {
            shizuku -> EngineMode.SHIZUKU
            accSetting || accConnected -> EngineMode.ACESSIBILIDADE
            else -> EngineMode.NATIVO
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), EngineMode.NATIVO)

    val activeProfile: StateFlow<KeymapProfile> = combine(_profiles, _activeProfileId) { list, id ->
        list.firstOrNull { it.id == id } ?: list.first()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ProfileRepository.defaultProfiles().first())

    private var dpiRevertJob: Job? = null
    private var previousDpiBeforeChange: Int? = null

    private val inputDeviceListener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) = refreshPeripherals()
        override fun onInputDeviceRemoved(deviceId: Int) = refreshPeripherals()
        override fun onInputDeviceChanged(deviceId: Int) = refreshPeripherals()
    }

    init {
        ShizukuBridge.init()
        inputManager.registerInputDeviceListener(inputDeviceListener, null)

        viewModelScope.launch {
            repository.profilesFlow.collectLatest { list ->
                _profiles.value = list
                syncRuntimeActiveProfile()
            }
        }
        viewModelScope.launch {
            repository.activeProfileIdFlow.collectLatest { id ->
                _activeProfileId.value = id
                syncRuntimeActiveProfile()
            }
        }
        viewModelScope.launch {
            repository.useShizukuInputFlow.collectLatest { useShizuku ->
                KeymapperRuntimeState.setUseShizukuInjection(useShizuku)
            }
        }
        viewModelScope.launch {
            repository.thermalShieldFlow.collectLatest { enabled ->
                _performanceState.value = _performanceState.value.copy(thermalShieldEnabled = enabled)
            }
        }
        viewModelScope.launch {
            repository.gameProfileMapFlow.collectLatest { map ->
                _gameProfileMap.value = map
            }
        }
        viewModelScope.launch {
            KeymapperRuntimeState.profileModifiedFromOverlay.collectLatest { updated ->
                val list = _profiles.value.map { if (it.id == updated.id) updated else it }
                _profiles.value = list
                repository.saveProfiles(list)
            }
        }

        // Live telemetry polling loop
        viewModelScope.launch {
            while (true) {
                val t = engine.readHardwareTelemetry()
                _telemetry.value = t
                _ramHistory.value = (_ramHistory.value + t.usedRamPercent.toFloat()).takeLast(24)
                _tempHistory.value = (_tempHistory.value + t.batteryTempC).takeLast(24)

                // Automatic thermal shield trigger (> 39.0 C)
                val perf = _performanceState.value
                if (perf.thermalShieldEnabled && t.batteryTempC > 39.0f && !perf.thermalShieldTriggered) {
                    val dimmed = engine.applyThermalBrightnessReduction(true)
                    if (dimmed) {
                        _performanceState.value = perf.copy(thermalShieldTriggered = true)
                        postStatus("Escudo Térmico: Brilho reduzido (${t.batteryTempC}°C > 39°C)")
                    }
                } else if (perf.thermalShieldTriggered && t.batteryTempC <= 37.5f) {
                    _performanceState.value = perf.copy(thermalShieldTriggered = false)
                }

                delay(1500L)
            }
        }

        // Live ping/jitter polling loop
        viewModelScope.launch {
            while (true) {
                if (_pingMonitorRunning.value) {
                    val prevDns1 = _pingHistory.value.lastOrNull()?.dns1Ms
                    val sample = engine.measurePingSample(prevDns1)
                    _pingHistory.value = (_pingHistory.value + sample).takeLast(30)
                }
                delay(1500L)
            }
        }

        refreshInstalledApps()
    }

    override fun onCleared() {
        inputManager.unregisterInputDeviceListener(inputDeviceListener)
        super.onCleared()
    }

    fun selectTab(tab: BotxTab) {
        _currentTab.value = tab
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun postStatus(msg: String) {
        _statusMessage.value = msg
    }

    fun refreshPermissionsAndHardware() {
        ShizukuBridge.refreshStatus()
        _hasOverlayPermission.value = engine.hasOverlayPermission()
        _hasAccessibilityEnabled.value = engine.isAccessibilityEnabled()
        _hasWriteSettings.value = engine.hasWriteSettingsPermission()
        _hasDndPermission.value = engine.hasDndPermission()
        _peripherals.value = engine.detectConnectedPeripherals()
        _telemetry.value = engine.readHardwareTelemetry()
    }

    fun refreshPeripherals() {
        _peripherals.value = engine.detectConnectedPeripherals()
    }

    fun refreshInstalledApps() {
        viewModelScope.launch {
            _installedApps.value = engine.loadInstalledApps()
        }
    }

    // --- Tab 1: Painel ---

    fun activateTurboMode(activity: Activity?) {
        viewModelScope.launch {
            val freed = engine.cleanIdleRam()
            val dndOk = engine.setDoNotDisturb(true)
            val rotOk = engine.setLandscapeLock(activity, true)
            KeymapperRuntimeState.setMappingActive(true)
            syncRuntimeActiveProfile()
            _mobiladorState.value = _mobiladorState.value.copy(landscapeLocked = true)
            _performanceState.value = _performanceState.value.copy(
                turboActive = true,
                dndActive = dndOk,
                lastFreedRamMb = freed
            )
            val extras = buildString {
                append("Turbo BOTX Ativo! +${freed}MB RAM livre")
                if (dndOk) append(" • DND ON")
                if (rotOk) append(" • Paisagem Travada")
            }
            postStatus(extras)
        }
    }

    fun deactivateTurboMode(activity: Activity?) {
        viewModelScope.launch {
            engine.setDoNotDisturb(false)
            engine.setLandscapeLock(activity, false)
            _mobiladorState.value = _mobiladorState.value.copy(landscapeLocked = false)
            _performanceState.value = _performanceState.value.copy(
                turboActive = false,
                dndActive = false
            )
            postStatus("Modo Turbo BOTX desativado.")
        }
    }

    fun launchGameWithProfile(app: InstalledAppInfo, activity: Activity?) {
        viewModelScope.launch {
            val mappedId = _gameProfileMap.value[app.packageName]
            if (mappedId != null) {
                repository.setActiveProfileId(mappedId)
                _activeProfileId.value = mappedId
                syncRuntimeActiveProfile()
            }
            if (!_performanceState.value.turboActive) {
                val freed = engine.cleanIdleRam()
                _performanceState.value = _performanceState.value.copy(lastFreedRamMb = freed)
            }
            if (_hasOverlayPermission.value && !KeymapperRuntimeState.isOverlayRunning.value) {
                BotxOverlayService.start(getApplication())
            }
            val launched = engine.launchPackage(app.packageName)
            if (launched) {
                postStatus("Iniciando ${app.label} com perfil ${activeProfile.value.name}")
            } else {
                postStatus("Não foi possível abrir ${app.label}.")
            }
        }
    }

    // --- Tab 2: Mapeador ---

    fun requestOverlayPermission() = engine.openOverlayPermissionSettings()
    fun requestAccessibilitySettings() = engine.openAccessibilitySettings()
    fun requestWriteSettingsPermission() = engine.openWriteSettingsPermission()
    fun requestDndPermission() = engine.openDndPermissionSettings()

    fun requestShizukuPermission() {
        val ok = ShizukuBridge.requestPermission(getApplication())
        if (!ok) {
            postStatus("Shizuku não detectado em execução. Inicie o serviço Shizuku primeiro.")
        } else {
            postStatus("Verificando autorização Shizuku...")
        }
    }

    fun setUseShizukuInput(enabled: Boolean) {
        viewModelScope.launch {
            if (enabled && !isShizukuReady.value) {
                requestShizukuPermission()
                return@launch
            }
            repository.setUseShizukuInput(enabled)
            KeymapperRuntimeState.setUseShizukuInjection(enabled)
            postStatus(if (enabled) "Injeção Shizuku Ultra-Low Latency ativada." else "Motor via Acessibilidade selecionado.")
        }
    }

    fun selectProfile(profileId: String) {
        viewModelScope.launch {
            _activeProfileId.value = profileId
            repository.setActiveProfileId(profileId)
            syncRuntimeActiveProfile()
        }
    }

    fun createProfile(name: String, linkedPackage: String = "") {
        if (name.isBlank()) return
        viewModelScope.launch {
            val newProfile = KeymapProfile(
                id = "prof_${UUID.randomUUID().toString().take(8)}",
                name = name.trim(),
                packageName = linkedPackage,
                elements = ProfileRepository.defaultProfiles().first().elements
            )
            val updated = _profiles.value + newProfile
            _profiles.value = updated
            _activeProfileId.value = newProfile.id
            repository.saveProfiles(updated)
            repository.setActiveProfileId(newProfile.id)
            if (linkedPackage.isNotBlank()) {
                repository.bindGameToProfile(linkedPackage, newProfile.id)
            }
            syncRuntimeActiveProfile()
            postStatus("Perfil '${newProfile.name}' criado e salvo em JSON.")
        }
    }

    fun deleteProfile(profileId: String) {
        if (_profiles.value.size <= 1) {
            postStatus("Mantenha ao menos um perfil de mapeamento.")
            return
        }
        viewModelScope.launch {
            val updated = _profiles.value.filterNot { it.id == profileId }
            _profiles.value = updated
            val fallbackId = updated.first().id
            if (_activeProfileId.value == profileId) {
                _activeProfileId.value = fallbackId
                repository.setActiveProfileId(fallbackId)
            }
            repository.saveProfiles(updated)
            syncRuntimeActiveProfile()
            postStatus("Perfil removido.")
        }
    }

    fun bindGameToCurrentProfile(packageName: String) {
        viewModelScope.launch {
            val profId = _activeProfileId.value
            repository.bindGameToProfile(packageName, profId)
            postStatus("Jogo vinculado ao perfil ${activeProfile.value.name}")
        }
    }

    fun updateActiveProfileSensitivity(sensX: Float, sensY: Float, smoothing: Float) {
        updateCurrentProfile {
            it.copy(
                sensitivityX = sensX,
                sensitivityY = sensY,
                dragSmoothing = smoothing
            )
        }
    }

    fun updateAimToggleKey(keyCode: Int) {
        updateCurrentProfile { it.copy(aimToggleKeyCode = keyCode) }
    }

    fun addOrUpdateElementInActiveProfile(element: KeyMappingElement) {
        updateCurrentProfile { prof ->
            val mutable = prof.elements.toMutableList()
            val idx = mutable.indexOfFirst { it.id == element.id }
            if (idx >= 0) mutable[idx] = element else mutable.add(element)
            prof.copy(elements = mutable)
        }
    }

    fun removeElementFromActiveProfile(elementId: String) {
        updateCurrentProfile { prof ->
            prof.copy(elements = prof.elements.filterNot { it.id == elementId })
        }
    }

    fun toggleFloatingBubble() {
        val ctx = getApplication<Application>()
        if (!engine.hasOverlayPermission()) {
            engine.openOverlayPermissionSettings()
            postStatus("Conceda a permissão de Sobreposição de Tela para abrir a bolinha BOTX.")
            return
        }
        if (KeymapperRuntimeState.isOverlayRunning.value) {
            BotxOverlayService.stop(ctx)
            postStatus("Bolinha Flutuante BOTX encerrada.")
        } else {
            syncRuntimeActiveProfile()
            BotxOverlayService.start(ctx)
            postStatus("Bolinha Flutuante BOTX iniciada! Toque nela sobre qualquer jogo.")
        }
    }

    fun exportActiveProfileJson(): String = repository.exportProfileJson(activeProfile.value)

    private fun updateCurrentProfile(transform: (KeymapProfile) -> KeymapProfile) {
        viewModelScope.launch {
            val curId = _activeProfileId.value
            val updatedList = _profiles.value.map { if (it.id == curId) transform(it) else it }
            _profiles.value = updatedList
            repository.saveProfiles(updatedList)
            syncRuntimeActiveProfile()
        }
    }

    private fun syncRuntimeActiveProfile() {
        val active = _profiles.value.firstOrNull { it.id == _activeProfileId.value } ?: _profiles.value.first()
        KeymapperRuntimeState.setActiveProfile(active)
    }

    // --- Tab 3: Mobilador ---

    fun updateCustomDpiInput(value: String) {
        _mobiladorState.value = _mobiladorState.value.copy(customDpiInput = value.filter { it.isDigit() }.take(3))
    }

    fun applyCustomDpiWithSafetyTimer() {
        val targetDpi = _mobiladorState.value.customDpiInput.toIntOrNull()
        if (targetDpi == null || targetDpi !in 160..960) {
            postStatus("Informe um DPI válido entre 160 e 960.")
            return
        }
        if (!isShizukuReady.value) {
            postStatus("Shizuku necessário para aplicar 'wm density'. Conecte o Shizuku primeiro.")
            return
        }
        viewModelScope.launch {
            previousDpiBeforeChange = _telemetry.value.currentDpi
            val res = engine.applyCustomDpi(targetDpi)
            if (!res.success) {
                postStatus("Falha ao aplicar DPI: ${res.output}")
                return@launch
            }
            _telemetry.value = engine.readHardwareTelemetry()
            startDpiRevertCountdown()
            postStatus("DPI ${targetDpi} aplicado! Confirme em 15s ou será revertido.")
        }
    }

    private fun startDpiRevertCountdown() {
        dpiRevertJob?.cancel()
        dpiRevertJob = viewModelScope.launch {
            for (sec in 15 downTo 1) {
                _mobiladorState.value = _mobiladorState.value.copy(dpiRevertSecondsRemaining = sec)
                delay(1000L)
            }
            _mobiladorState.value = _mobiladorState.value.copy(dpiRevertSecondsRemaining = 0)
            revertCustomDpi()
        }
    }

    fun confirmCustomDpi() {
        dpiRevertJob?.cancel()
        _mobiladorState.value = _mobiladorState.value.copy(dpiRevertSecondsRemaining = 0)
        postStatus("Novo DPI confirmado!")
    }

    fun revertCustomDpi() {
        dpiRevertJob?.cancel()
        viewModelScope.launch {
            _mobiladorState.value = _mobiladorState.value.copy(dpiRevertSecondsRemaining = 0)
            val res = engine.resetDpi()
            _telemetry.value = engine.readHardwareTelemetry()
            postStatus(if (res.success) "DPI restaurado ao padrão com segurança." else "Erro ao restaurar DPI: ${res.output}")
        }
    }

    fun setPointerSpeed(speed: Int) {
        viewModelScope.launch {
            val ok = engine.setPointerSpeed(speed)
            _mobiladorState.value = _mobiladorState.value.copy(pointerSpeed = speed)
            if (!ok) {
                postStatus("Conceda Modificar Configurações do Sistema ou Shizuku para ajustar o ponteiro.")
            }
        }
    }

    fun setLongPressPreset(ms: Int) {
        viewModelScope.launch {
            val ok = engine.setLongPressTimeout(ms)
            _mobiladorState.value = _mobiladorState.value.copy(longPressTimeoutMs = ms)
            postStatus(
                if (ok) "Tempo de resposta do toque definido para ${ms}ms."
                else "Requer Shizuku para gravar Settings.Secure (long_press_timeout)."
            )
        }
    }

    fun toggleTouchSensitivity(enabled: Boolean) {
        viewModelScope.launch {
            val ok = engine.setTouchSensitivity(enabled)
            _mobiladorState.value = _mobiladorState.value.copy(touchSensitivity = enabled)
            postStatus(
                if (ok) "Modo Película / Toque Sensível ${if (enabled) "ATIVADO" else "DESATIVADO"}."
                else "Permissão de sistema ou Shizuku necessária para touch_sensitivity."
            )
        }
    }

    fun toggleLandscapeLock(activity: Activity?, locked: Boolean) {
        viewModelScope.launch {
            engine.setLandscapeLock(activity, locked)
            _mobiladorState.value = _mobiladorState.value.copy(landscapeLocked = locked)
            postStatus(if (locked) "Rotação travada em Paisagem." else "Rotação automática restaurada.")
        }
    }

    fun toggleImmersiveMode(activity: Activity?, enabled: Boolean) {
        viewModelScope.launch {
            engine.setImmersiveMode(activity, enabled)
            _mobiladorState.value = _mobiladorState.value.copy(immersiveMode = enabled)
            postStatus(if (enabled) "Modo Imersivo ativado (barras ocultas)." else "Barras do sistema restauradas.")
        }
    }

    // --- Tab 4: Desempenho ---

    fun toggleZeroAnimations(enabled: Boolean) {
        viewModelScope.launch {
            val ok = engine.setZeroAnimations(enabled)
            if (ok) {
                _performanceState.value = _performanceState.value.copy(zeroAnimationsActive = enabled)
                postStatus(if (enabled) "Animações do sistema zeradas (0.0x)." else "Animações restauradas (1.0x).")
            } else {
                postStatus("Shizuku necessário para alterar escalas globais de animação.")
            }
        }
    }

    fun toggleMaxRefreshRate(activity: Activity?, enabled: Boolean) {
        viewModelScope.launch {
            val hz = engine.forceMaxRefreshRate(activity, enabled)
            _performanceState.value = _performanceState.value.copy(maxRefreshRateForced = enabled)
            _telemetry.value = engine.readHardwareTelemetry()
            postStatus(if (enabled) "Taxa de atualização máxima aplicada (${hz}Hz)." else "Taxa de atualização dinâmica restaurada.")
        }
    }

    fun runDeepRamCleanup() {
        viewModelScope.launch {
            val freed = engine.cleanIdleRam()
            _performanceState.value = _performanceState.value.copy(lastFreedRamMb = freed)
            _telemetry.value = engine.readHardwareTelemetry()
            postStatus("Limpeza concluída: ${freed} MB liberados da RAM ociosa.")
        }
    }

    fun runAotCompileForApp(app: InstalledAppInfo) {
        if (!isShizukuReady.value) {
            postStatus("Shizuku necessário para compilação AOT (cmd package compile).")
            return
        }
        viewModelScope.launch {
            _performanceState.value = _performanceState.value.copy(
                lastAotStatus = "Compilando ${app.label} (speed)..."
            )
            val res = engine.compileAotSpeed(app.packageName)
            val statusText = if (res.success) {
                "AOT Speed concluído: ${app.label}"
            } else {
                "Falha AOT (${app.label}): ${res.output.ifBlank { "Erro código ${res.exitCode}" }}"
            }
            _performanceState.value = _performanceState.value.copy(lastAotStatus = statusText)
            postStatus(statusText)
        }
    }

    fun toggleDoNotDisturb(enabled: Boolean) {
        if (!engine.hasDndPermission()) {
            engine.openDndPermissionSettings()
            postStatus("Conceda acesso ao Não Perturbe para ativar o Modo Sem Distrações.")
            return
        }
        val ok = engine.setDoNotDisturb(enabled)
        _performanceState.value = _performanceState.value.copy(dndActive = ok && enabled)
        postStatus(if (enabled) "Não Perturbe ativado." else "Notificações restauradas.")
    }

    fun toggleThermalShield(enabled: Boolean) {
        viewModelScope.launch {
            if (enabled && !engine.hasWriteSettingsPermission()) {
                engine.openWriteSettingsPermission()
                postStatus("Conceda Modificar Configurações para o Escudo Térmico controlar o brilho.")
                return@launch
            }
            repository.setThermalShield(enabled)
            _performanceState.value = _performanceState.value.copy(thermalShieldEnabled = enabled)
            postStatus(if (enabled) "Escudo Térmico >39°C ativado." else "Escudo Térmico desativado.")
        }
    }

    fun toggleDisableHaptics(disabled: Boolean) {
        viewModelScope.launch {
            val ok = engine.setHapticDisabled(disabled)
            _performanceState.value = _performanceState.value.copy(hapticDisabled = disabled)
            postStatus(
                if (ok) "Vibração tátil ${if (disabled) "desativada" else "ativada"}."
                else "Permissão de sistema ou Shizuku necessária para vibração tátil."
            )
        }
    }

    // --- Tab 5: Rede & Sistema ---

    fun togglePingMonitor() {
        _pingMonitorRunning.value = !_pingMonitorRunning.value
    }

    fun disableCaptivePortalChecks() {
        viewModelScope.launch {
            if (!isShizukuReady.value) {
                postStatus("Conecte o Shizuku para desativar verificações de Captive Portal.")
                return@launch
            }
            val res = engine.disableCaptivePortalChecks()
            postStatus(
                if (res.success) "Testes de Captive Portal desativados."
                else "Erro: ${res.output}"
            )
        }
    }

    fun openBackgroundDataRestrictions() {
        engine.openBackgroundDataSettings()
    }

    fun getBackgroundDataStatus(): String = engine.getBackgroundRestrictionStatusLabel()

    fun forceStopApp(app: InstalledAppInfo) {
        viewModelScope.launch {
            if (!isShizukuReady.value) {
                postStatus("Shizuku necessário para Forçar Parada de ${app.label}.")
                return@launch
            }
            val res = engine.forceStopApp(app.packageName)
            postStatus(if (res.success) "${app.label} encerrado (force-stop)." else "Erro: ${res.output}")
        }
    }

    fun toggleFreezeApp(app: InstalledAppInfo) {
        viewModelScope.launch {
            if (!isShizukuReady.value) {
                postStatus("Shizuku necessário para congelar/descongelar apps.")
                return@launch
            }
            val freeze = app.isEnabled
            val res = engine.setAppFrozen(app.packageName, freeze)
            if (res.success) {
                _installedApps.value = _installedApps.value.map {
                    if (it.packageName == app.packageName) it.copy(isEnabled = !freeze) else it
                }
                postStatus(if (freeze) "${app.label} congelado!" else "${app.label} descongelado!")
            } else {
                postStatus("Erro ao alterar estado de ${app.label}: ${res.output}")
            }
        }
    }
}
