package com.example.ui.screens

import android.app.Activity
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.HardwareTelemetry
import com.example.data.InstalledAppInfo
import com.example.data.KeymapProfile
import com.example.data.PerformanceState
import com.example.data.PeripheralDevice
import com.example.ui.components.BotxCard
import com.example.ui.components.LiveMetricLineChart
import com.example.ui.components.SectionHeader
import com.example.ui.theme.BotxAmber
import com.example.ui.theme.BotxBorderSubtle
import com.example.ui.theme.BotxCardElevated
import com.example.ui.theme.BotxCyan
import com.example.ui.theme.BotxEmerald
import com.example.ui.theme.BotxNeonRed
import com.example.ui.theme.BotxNeonRedDark
import com.example.ui.theme.BotxNeonRedGlow
import com.example.ui.theme.BotxObsidianBg
import com.example.ui.theme.BotxTextMuted
import com.example.ui.theme.BotxTextPrimary
import com.example.ui.theme.BotxTextSecondary

@Composable
fun PainelScreen(
    telemetry: HardwareTelemetry,
    ramHistory: List<Float>,
    tempHistory: List<Float>,
    peripherals: List<PeripheralDevice>,
    installedApps: List<InstalledAppInfo>,
    activeProfile: KeymapProfile,
    performanceState: PerformanceState,
    gameProfileMap: Map<String, String>,
    allProfiles: List<KeymapProfile>,
    onActivateTurbo: (Activity?) -> Unit,
    onDeactivateTurbo: (Activity?) -> Unit,
    onRefreshPeripherals: () -> Unit,
    onRefreshApps: () -> Unit,
    onLaunchGame: (InstalledAppInfo, Activity?) -> Unit
) {
    val activity = LocalContext.current as? Activity
    var showAllApps by remember { mutableStateOf(false) }

    val displayedGames = remember(installedApps, showAllApps) {
        if (showAllApps) installedApps else installedApps.filter { it.isGame }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Modo Turbo BOTX (1-Clique)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .border(
                        1.dp,
                        if (performanceState.turboActive) BotxNeonRed else BotxBorderSubtle,
                        RoundedCornerShape(14.dp)
                    )
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_tactical_banner_1794615042976),
                    contentDescription = "Banner Tático BOTX",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.matchParentSize()
                )
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    BotxObsidianBg.copy(alpha = 0.94f),
                                    BotxObsidianBg.copy(alpha = 0.78f)
                                )
                            )
                        )
                )
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "MODO TURBO BOTX",
                                style = MaterialTheme.typography.headlineSmall,
                                color = BotxTextPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Ativa Não Perturbe, trava rotação paisagem, limpa RAM ociosa e carrega '${activeProfile.name}'.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = BotxTextSecondary
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = {
                            if (performanceState.turboActive) onDeactivateTurbo(activity)
                            else onActivateTurbo(activity)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("turbo_mode_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (performanceState.turboActive) BotxCardElevated else BotxNeonRed,
                            contentColor = BotxTextPrimary
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = if (performanceState.turboActive) BotxEmerald else BotxTextPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (performanceState.turboActive) "TURBO ATIVO • TOQUE PARA DESATIVAR"
                            else "ATIVAR MODO TURBO (1-CLIQUE)",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }

        // 2. Telemetria de Hardware em Tempo Real
        item {
            SectionHeader(
                title = "Telemetria de Hardware",
                subtitle = "Monitoramento em tempo real do dispositivo",
                icon = Icons.Default.Memory
            )
            Spacer(modifier = Modifier.height(8.dp))
            BotxCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TelemetryStatCell(
                        label = "MODELO",
                        value = telemetry.deviceModel,
                        modifier = Modifier.weight(1f)
                    )
                    TelemetryStatCell(
                        label = "SISTEMA",
                        value = "Android ${telemetry.androidVersion} (API ${telemetry.apiLevel})",
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TelemetryStatCell(
                        label = "CPU / ABI",
                        value = "${telemetry.cpuCores} Cores • ${telemetry.cpuAbi}",
                        modifier = Modifier.weight(1f)
                    )
                    TelemetryStatCell(
                        label = "RAM LIVRE / TOTAL",
                        value = "${telemetry.availableRamMb} / ${telemetry.totalRamMb} MB",
                        accent = BotxCyan,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TelemetryStatCell(
                        label = "BATERIA & TENSÃO",
                        value = "${telemetry.batteryPercent}% • ${telemetry.batteryVoltageMv}mV",
                        accent = if (telemetry.isCharging) BotxEmerald else BotxTextPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    TelemetryStatCell(
                        label = "TELA & DPI",
                        value = "${telemetry.refreshRateHz}Hz • ${telemetry.currentDpi} DPI",
                        accent = BotxNeonRed,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                LiveMetricLineChart(
                    title = "USO DE RAM",
                    currentValueText = "${telemetry.usedRamPercent}%",
                    samples = ramHistory,
                    minVal = 0f,
                    maxVal = 100f,
                    lineColor = BotxNeonRed,
                    chartHeight = 80.dp,
                    modifier = Modifier.weight(1f)
                )
                LiveMetricLineChart(
                    title = "TEMPERATURA",
                    currentValueText = "${"%.1f".format(telemetry.batteryTempC)}°C",
                    samples = tempHistory,
                    minVal = 20f,
                    maxVal = 55f,
                    lineColor = if (telemetry.batteryTempC >= 39f) BotxNeonRed else BotxAmber,
                    chartHeight = 80.dp,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // 3. Detector de Periféricos OTG / Bluetooth
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionHeader(
                    title = "Periféricos OTG / Bluetooth",
                    subtitle = "${peripherals.size} dispositivo(s) físico(s) detectado(s)",
                    icon = Icons.Default.Usb
                )
                IconButton(
                    onClick = onRefreshPeripherals,
                    modifier = Modifier.testTag("refresh_peripherals_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reescanear periféricos",
                        tint = BotxNeonRed
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            if (peripherals.isEmpty()) {
                BotxCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Devices,
                            contentDescription = null,
                            tint = BotxTextMuted,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Nenhum Mouse ou Teclado físico conectado",
                                style = MaterialTheme.typography.titleSmall,
                                color = BotxTextPrimary
                            )
                            Text(
                                text = "Conecte um hub OTG ou pareie via Bluetooth. O InputManager detectará automaticamente.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = BotxTextSecondary
                            )
                        }
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    peripherals.forEach { dev ->
                        BotxCard(highlighted = true) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = if (dev.isMouse) Icons.Default.Mouse else Icons.Default.Keyboard,
                                        contentDescription = dev.name,
                                        tint = BotxNeonRed,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = dev.name,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = BotxTextPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "ID ${dev.id} • VID:${dev.vendorId} PID:${dev.productId}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = BotxTextSecondary
                                        )
                                    }
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(BotxEmerald.copy(alpha = 0.16f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = when {
                                            dev.isMouse && dev.isKeyboard -> "COMBO"
                                            dev.isMouse -> "MOUSE"
                                            else -> "TECLADO"
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = BotxEmerald
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. Lançador Rápido de Jogos
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionHeader(
                    title = "Lançador Rápido de Jogos",
                    subtitle = "Inicia com perfil de mapeamento e otimizações",
                    icon = Icons.Default.SportsEsports
                )
                IconButton(onClick = onRefreshApps) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Atualizar lista de jogos",
                        tint = BotxTextSecondary
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = !showAllApps,
                    onClick = { showAllApps = false },
                    label = { Text("Somente Jogos", style = MaterialTheme.typography.labelSmall) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = BotxNeonRedGlow,
                        selectedLabelColor = BotxNeonRed
                    )
                )
                FilterChip(
                    selected = showAllApps,
                    onClick = { showAllApps = true },
                    label = { Text("Todos os Apps (${installedApps.size})", style = MaterialTheme.typography.labelSmall) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = BotxNeonRedGlow,
                        selectedLabelColor = BotxNeonRed
                    )
                )
            }
        }

        if (displayedGames.isEmpty()) {
            item {
                BotxCard {
                    Text(
                        text = "Nenhum jogo categorizado encontrado automaticamente.",
                        style = MaterialTheme.typography.titleSmall,
                        color = BotxTextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Toque em 'Todos os Apps' acima para escolher qualquer aplicativo instalado e iniciar com o perfil BOTX.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = BotxTextSecondary
                    )
                }
            }
        } else {
            items(displayedGames.take(30), key = { it.packageName }) { app ->
                val linkedProfileId = gameProfileMap[app.packageName]
                val linkedProfileName = allProfiles.firstOrNull { it.id == linkedProfileId }?.name
                    ?: activeProfile.name
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(BotxCardElevated)
                        .border(1.dp, BotxBorderSubtle, RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = app.label,
                            style = MaterialTheme.typography.titleSmall,
                            color = BotxTextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${app.packageName} • Perfil: $linkedProfileName",
                            style = MaterialTheme.typography.labelSmall,
                            color = BotxTextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onLaunchGame(app, activity) },
                        modifier = Modifier.testTag("launch_${app.packageName}"),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BotxNeonRed,
                            contentColor = BotxTextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Jogar", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("JOGAR", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun TelemetryStatCell(
    label: String,
    value: String,
    accent: Color = BotxTextPrimary,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.padding(end = 6.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = BotxTextMuted
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.labelLarge,
            color = accent,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
