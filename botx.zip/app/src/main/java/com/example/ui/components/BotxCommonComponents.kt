package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.theme.BotxBorderActive
import com.example.ui.theme.BotxBorderSubtle
import com.example.ui.theme.BotxCardElevated
import com.example.ui.theme.BotxCardSurface
import com.example.ui.theme.BotxEmerald
import com.example.ui.theme.BotxNeonRed
import com.example.ui.theme.BotxNeonRedGlow
import com.example.ui.theme.BotxTextMuted
import com.example.ui.theme.BotxTextPrimary
import com.example.ui.theme.BotxTextSecondary

@Composable
fun BotxCard(
    modifier: Modifier = Modifier,
    highlighted: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(BotxCardSurface)
            .border(
                width = 1.dp,
                color = if (highlighted) BotxNeonRed.copy(alpha = 0.7f) else BotxBorderSubtle,
                shape = RoundedCornerShape(12.dp)
            )
            .padding(14.dp),
        content = content
    )
}

@Composable
fun SectionHeader(
    title: String,
    subtitle: String? = null,
    icon: ImageVector? = null,
    accent: Color = BotxNeonRed
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
        }
        Column {
            Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.titleMedium,
                color = BotxTextPrimary
            )
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = BotxTextSecondary
                )
            }
        }
    }
}

@Composable
fun TacticalToggleRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    checked: Boolean,
    testTag: String,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(BotxCardSurface)
            .border(
                1.dp,
                if (checked) BotxBorderActive else BotxBorderSubtle,
                RoundedCornerShape(12.dp)
            )
            .clickable { onCheckedChange(!checked) }
            .minimumInteractiveComponentSize()
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(9.dp))
                    .background(if (checked) BotxNeonRedGlow else BotxCardElevated),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = if (checked) BotxNeonRed else BotxTextSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = BotxTextPrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = BotxTextSecondary
                )
            }
        }
        Spacer(modifier = Modifier.width(10.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag),
            colors = SwitchDefaults.colors(
                checkedThumbColor = BotxTextPrimary,
                checkedTrackColor = BotxNeonRed,
                uncheckedThumbColor = BotxTextMuted,
                uncheckedTrackColor = BotxCardElevated,
                uncheckedBorderColor = BotxBorderSubtle
            )
        )
    }
}

@Composable
fun PermissionStatusButton(
    title: String,
    description: String,
    granted: Boolean,
    icon: ImageVector,
    testTag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(BotxCardElevated)
            .border(
                1.dp,
                if (granted) BotxEmerald.copy(alpha = 0.55f) else BotxNeonRed.copy(alpha = 0.5f),
                RoundedCornerShape(10.dp)
            )
            .clickable { onClick() }
            .minimumInteractiveComponentSize()
            .testTag(testTag)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (granted) BotxEmerald else BotxNeonRed,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = BotxTextPrimary
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = BotxTextSecondary
                )
            }
        }
        Spacer(modifier = Modifier.width(8.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(if (granted) BotxEmerald.copy(alpha = 0.16f) else BotxNeonRedGlow)
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(
                text = if (granted) "ATIVO" else "ATIVAR",
                style = MaterialTheme.typography.labelSmall,
                color = if (granted) BotxEmerald else BotxNeonRed
            )
        }
    }
}
