package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.InstalledAppInfo
import com.example.data.PingSample
import com.example.ui.components.BotxCard
import com.example.ui.components.LiveMetricLineChart
import com.example.ui.components.SectionHeader
import com.example.ui.theme.BotxAmber
import com.example.ui.theme.BotxBorderSubtle
import com.example.ui.theme.BotxCardElevated
import com.example.ui.theme.BotxCyan
import com.example.ui.theme.BotxEmerald
import com.example.ui.theme.BotxNeonRed
import com.example.ui.theme.BotxTextMuted
import com.example.ui.theme.BotxTextPrimary
import com.example.ui.theme.BotxTextSecondary

@Composable
fun SistemaScreen(
    pingHistory: List<PingSample>,
    pingMonitorRunning: Boolean,
    installedApps: List<InstalledAppInfo>,
    isShizukuReady: Boolean,
    backgroundRestrictionStatus: String,
    onTogglePingMonitor: () -> Unit,
    onDisableCaptivePortal: () -> Unit,
    onOpenBackgroundDataSettings: () -> Unit,
    onForceStopApp: (InstalledAppInfo) -> Unit,
    onToggleFreezeApp: (InstalledAppInfo) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    val latest = pingHistory.lastOrNull()
    val dns1Series = remember(pingHistory) {
        pingHistory.map { it.dns1Ms.coerceAtMost(300).toFloat() }
    }
    val dns8Series = remember(pingHistory) {
        pingHistory.map { it.dns8Ms.coerceAtMost(300).toFloat() }
    }

    val filteredApps = remember(installedApps, searchQuery) {
        val q = searchQuery.trim().lowercase()
        val base = installedApps.filter { !it.isSystemApp }
        if (q.isEmpty()) base else base.filter {
            it.label.lowercase().contains(q) || it.packageName.lowercase().contains(q)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Monitor de Ping & Jitter em Tempo Real
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionHeader(
                    title = "Monitor de Ping & Jitter",
                    subtitle = "Latência TCP real para DNS 1.1.1.1 e 8.8.8.8",
                    icon = Icons.Default.NetworkCheck
                )
                IconButton(
                    onClick = onTogglePingMonitor,
                    modifier = Modifier.testTag("toggle_ping_btn")
                ) {
                    Icon(
                        imageVector = if (pingMonitorRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (pingMonitorRunning) "Pausar Ping" else "Iniciar Ping",
                        tint = BotxNeonRed
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            LiveMetricLineChart(
                title = "1.1.1.1 (VERMELHO) vs 8.8.8.8 (CIANO)",
                currentValueText = if (latest == null) "-- ms"
                else if (latest.packetLoss) "SEM REDE"
                else "${latest.dns1Ms}ms / ${latest.dns8Ms}ms",
                samples = dns1Series,
                secondarySamples = dns8Series,
                minVal = 0f,
                maxVal = 200f,
                lineColor = BotxNeonRed,
                secondaryColor = BotxCyan,
                chartHeight = 110.dp
            )
            Spacer(modifier = Modifier.height(8.dp))
            BotxCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    PingStat("DNS 1.1.1.1", latest?.let { if (it.dns1Ms >= 900) "TIMEOUT" else "${it.dns1Ms} ms" } ?: "--", BotxNeonRed)
                    PingStat("DNS 8.8.8.8", latest?.let { if (it.dns8Ms >= 900) "TIMEOUT" else "${it.dns8Ms} ms" } ?: "--", BotxCyan)
                    PingStat("JITTER", latest?.let { "${it.jitterMs} ms" } ?: "--", BotxAmber)
                }
            }
        }

        // 2. Bloqueio de Captive Portal e Dados de Fundo
        item {
            SectionHeader(
                title = "Captive Portal & Dados de Fundo",
                subtitle = "Evita verificações de rede em segundo plano durante partidas",
                icon = Icons.Default.Security
            )
            Spacer(modifier = Modifier.height(8.dp))
            BotxCard {
                Text(
                    text = "Status Atual: $backgroundRestrictionStatus",
                    style = MaterialTheme.typography.labelLarge,
                    color = BotxCyan
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onDisableCaptivePortal,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("disable_captive_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = BotxNeonRed),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Block, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Captive Portal OFF", style = MaterialTheme.typography.labelSmall)
                    }
                    OutlinedButton(
                        onClick = onOpenBackgroundDataSettings,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("open_bg_data_btn"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Dados de Fundo", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        // 3. Gerenciador e Congelador de Apps Pesados
        item {
            SectionHeader(
                title = "Gerenciador & Congelador de Apps",
                subtitle = if (isShizukuReady) "Forçar parada ou congelar via Shizuku (pm disable-user)"
                else "Conecte o Shizuku para congelar/descongelar apps",
                icon = Icons.Default.Apps
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                placeholder = { Text("Buscar aplicativo instalado...") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_apps_input")
            )
        }

        if (filteredApps.isEmpty()) {
            item {
                BotxCard {
                    Text(
                        text = "Nenhum aplicativo encontrado para '$searchQuery'.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = BotxTextSecondary
                    )
                }
            }
        } else {
            items(filteredApps.take(40), key = { it.packageName }) { app ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(BotxCardElevated)
                        .border(1.dp, BotxBorderSubtle, RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = app.label,
                                style = MaterialTheme.typography.titleSmall,
                                color = if (app.isEnabled) BotxTextPrimary else BotxTextMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (!app.isEnabled) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "CONGELADO",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = BotxCyan
                                )
                            }
                        }
                        Text(
                            text = app.packageName,
                            style = MaterialTheme.typography.labelSmall,
                            color = BotxTextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        IconButton(
                            onClick = { onForceStopApp(app) },
                            modifier = Modifier.testTag("stop_${app.packageName}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stop,
                                contentDescription = "Forçar Parada",
                                tint = BotxAmber
                            )
                        }
                        IconButton(
                            onClick = { onToggleFreezeApp(app) },
                            modifier = Modifier.testTag("freeze_${app.packageName}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AcUnit,
                                contentDescription = if (app.isEnabled) "Congelar App" else "Descongelar App",
                                tint = if (app.isEnabled) BotxCyan else BotxEmerald
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PingStat(label: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = BotxTextMuted)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, style = MaterialTheme.typography.labelLarge, color = color)
    }
}
