package com.example.ui.screens

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.ScreenLockLandscape
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.HardwareTelemetry
import com.example.data.MobiladorSettingsState
import com.example.ui.components.BotxCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.TacticalToggleRow
import com.example.ui.theme.BotxAmber
import com.example.ui.theme.BotxAmberBg
import com.example.ui.theme.BotxCardElevated
import com.example.ui.theme.BotxCyan
import com.example.ui.theme.BotxEmerald
import com.example.ui.theme.BotxNeonRed
import com.example.ui.theme.BotxNeonRedGlow
import com.example.ui.theme.BotxTextPrimary
import com.example.ui.theme.BotxTextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MobiladorScreen(
    telemetry: HardwareTelemetry,
    state: MobiladorSettingsState,
    isShizukuReady: Boolean,
    hasWriteSettings: Boolean,
    onRequestWriteSettings: () -> Unit,
    onDpiInputChange: (String) -> Unit,
    onApplyCustomDpi: () -> Unit,
    onConfirmCustomDpi: () -> Unit,
    onRevertCustomDpi: () -> Unit,
    onPointerSpeedChange: (Int) -> Unit,
    onLongPressPresetSelect: (Int) -> Unit,
    onToggleTouchSensitivity: (Boolean) -> Unit,
    onToggleLandscapeLock: (Activity?, Boolean) -> Unit,
    onToggleImmersiveMode: (Activity?, Boolean) -> Unit
) {
    val activity = LocalContext.current as? Activity

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (!hasWriteSettings) {
            item {
                BotxCard(highlighted = true) {
                    Text(
                        text = "Permissão de Sistema Recomendada",
                        style = MaterialTheme.typography.titleSmall,
                        color = BotxAmber
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Autorize 'Modificar configurações do sistema' para ajustar ponteiro, rotação e sensibilidade diretamente.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = BotxTextSecondary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = onRequestWriteSettings,
                        colors = ButtonDefaults.buttonColors(containerColor = BotxNeonRed)
                    ) {
                        Text("CONCEDER WRITE_SETTINGS", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }

        // 1. DPI Personalizado com Reversão Segura (15s)
        item {
            SectionHeader(
                title = "DPI Personalizado (wm density)",
                subtitle = "Reversão automática segura em 15 segundos se não confirmado",
                icon = Icons.Default.AspectRatio
            )
            Spacer(modifier = Modifier.height(8.dp))
            BotxCard(highlighted = state.dpiRevertSecondsRemaining > 0) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "DPI Atual: ${telemetry.currentDpi}",
                        style = MaterialTheme.typography.labelLarge,
                        color = BotxCyan
                    )
                    Text(
                        text = if (isShizukuReady) "SHIZUKU PRONTO" else "REQUER SHIZUKU",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isShizukuReady) BotxEmerald else BotxAmber
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))

                if (state.dpiRevertSecondsRemaining > 0) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(BotxAmberBg)
                            .border(1.dp, BotxAmber, RoundedCornerShape(10.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "CONFIRME O NOVO DPI EM ${state.dpiRevertSecondsRemaining}s",
                            style = MaterialTheme.typography.labelLarge,
                            color = BotxAmber
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = onConfirmCustomDpi,
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = BotxEmerald)
                            ) {
                                Text("MANTER", style = MaterialTheme.typography.labelMedium)
                            }
                            OutlinedButton(
                                onClick = onRevertCustomDpi,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("REVERTER", style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = state.customDpiInput,
                            onValueChange = onDpiInputChange,
                            label = { Text("DPI (160–960)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("custom_dpi_input")
                        )
                        Button(
                            onClick = onApplyCustomDpi,
                            modifier = Modifier
                                .height(54.dp)
                                .testTag("apply_dpi_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = BotxNeonRed)
                        ) {
                            Text("APLICAR", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = onRevertCustomDpi,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Restaurar DPI Padrão (wm density reset)", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        // 2. Velocidade do Ponteiro do Mouse (-7 a +7)
        item {
            SectionHeader(
                title = "Velocidade do Ponteiro do Mouse",
                subtitle = "Settings.System.POINTER_SPEED (-7 a +7)",
                icon = Icons.Default.Mouse
            )
            Spacer(modifier = Modifier.height(8.dp))
            BotxCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Nível do Ponteiro",
                        style = MaterialTheme.typography.titleSmall,
                        color = BotxTextPrimary
                    )
                    Text(
                        text = if (state.pointerSpeed > 0) "+${state.pointerSpeed}" else "${state.pointerSpeed}",
                        style = MaterialTheme.typography.labelLarge,
                        color = BotxNeonRed
                    )
                }
                Slider(
                    value = state.pointerSpeed.toFloat(),
                    onValueChange = { onPointerSpeedChange(it.toInt()) },
                    valueRange = -7f..7f,
                    steps = 13,
                    modifier = Modifier.testTag("pointer_speed_slider"),
                    colors = SliderDefaults.colors(
                        thumbColor = BotxNeonRed,
                        activeTrackColor = BotxNeonRed,
                        inactiveTrackColor = BotxCardElevated
                    )
                )
            }
        }

        // 3. Tempo de Resposta do Toque (Toque Longo)
        item {
            SectionHeader(
                title = "Tempo de Resposta (Toque Longo)",
                subtitle = "Define long_press_timeout no sistema",
                icon = Icons.Default.Timer
            )
            Spacer(modifier = Modifier.height(8.dp))
            BotxCard {
                val presets = listOf(
                    100 to "100ms",
                    150 to "150ms",
                    200 to "200ms",
                    300 to "300ms",
                    400 to "Padrão (400ms)"
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    presets.forEach { (ms, label) ->
                        FilterChip(
                            selected = state.longPressTimeoutMs == ms,
                            onClick = { onLongPressPresetSelect(ms) },
                            label = { Text(label, style = MaterialTheme.typography.labelMedium) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BotxNeonRedGlow,
                                selectedLabelColor = BotxNeonRed
                            )
                        )
                    }
                }
            }
        }

        // 4. Toque Sensível, Landscape Lock, Modo Imersivo
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                TacticalToggleRow(
                    title = "Toque Sensível / Modo Película",
                    subtitle = "Ativa touch_sensitivity = 1 para resposta rápida",
                    icon = Icons.Default.TouchApp,
                    checked = state.touchSensitivity,
                    testTag = "touch_sensitivity_switch",
                    onCheckedChange = onToggleTouchSensitivity
                )
                TacticalToggleRow(
                    title = "Trava de Rotação Paisagem",
                    subtitle = "Mantém tela travada na horizontal (ACCELEROMETER_ROTATION = 0)",
                    icon = Icons.Default.ScreenLockLandscape,
                    checked = state.landscapeLocked,
                    testTag = "landscape_lock_switch",
                    onCheckedChange = { onToggleLandscapeLock(activity, it) }
                )
                TacticalToggleRow(
                    title = "Modo Imersivo (Bloqueio de Barras)",
                    subtitle = "Oculta barras de status e navegação contra cliques acidentais",
                    icon = Icons.Default.Fullscreen,
                    checked = state.immersiveMode,
                    testTag = "immersive_mode_switch",
                    onCheckedChange = { onToggleImmersiveMode(activity, it) }
                )
            }
        }
    }
}
