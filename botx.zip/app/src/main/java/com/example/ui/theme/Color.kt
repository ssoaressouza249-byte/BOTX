package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BotxObsidianBg = Color(0xFF070709)
val BotxCardSurface = Color(0xFF111216)
val BotxCardElevated = Color(0xFF171920)
val BotxBorderSubtle = Color(0xFF22242C)
val BotxBorderActive = Color(0xFF3A1620)

val BotxNeonRed = Color(0xFFFF1E42)
val BotxNeonRedDark = Color(0xFFB30E29)
val BotxNeonRedGlow = Color(0x33FF1E42)

val BotxTextPrimary = Color(0xFFF3F4F8)
val BotxTextSecondary = Color(0xFF9499AB)
val BotxTextMuted = Color(0xFF606577)

val BotxEmerald = Color(0xFF00E676)
val BotxEmeraldBg = Color(0x1F00E676)
val BotxAmber = Color(0xFFFFB300)
val BotxAmberBg = Color(0x1FFFB300)
val BotxCyan = Color(0xFF00E5FF)
val BotxCyanBg = Color(0x1F00E5FF)
