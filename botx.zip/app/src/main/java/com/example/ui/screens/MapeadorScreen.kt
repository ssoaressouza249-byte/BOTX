package com.example.ui.screens

import android.view.KeyEvent
import android.view.MotionEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.InstalledAppInfo
import com.example.data.KeyCodeFormatter
import com.example.data.KeyMappingElement
import com.example.data.KeymapProfile
import com.example.data.MappingElementType
import com.example.ui.components.BotxCard
import com.example.ui.components.PermissionStatusButton
import com.example.ui.components.SectionHeader
import com.example.ui.theme.BotxBorderSubtle
import com.example.ui.theme.BotxCardElevated
import com.example.ui.theme.BotxCyan
import com.example.ui.theme.BotxEmerald
import com.example.ui.theme.BotxNeonRed
import com.example.ui.theme.BotxNeonRedGlow
import com.example.ui.theme.BotxTextMuted
import com.example.ui.theme.BotxTextPrimary
import com.example.ui.theme.BotxTextSecondary
import java.util.UUID
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MapeadorScreen(
    hasOverlayPermission: Boolean,
    hasAccessibilityEnabled: Boolean,
    isShizukuReady: Boolean,
    useShizukuInjection: Boolean,
    isOverlayRunning: Boolean,
    isAimModeLocked: Boolean,
    lastInputLabel: String,
    profiles: List<KeymapProfile>,
    activeProfile: KeymapProfile,
    installedApps: List<InstalledAppInfo>,
    onRequestOverlay: () -> Unit,
    onRequestAccessibility: () -> Unit,
    onRequestShizuku: () -> Unit,
    onToggleShizukuInput: (Boolean) -> Unit,
    onToggleFloatingBubble: () -> Unit,
    onSelectProfile: (String) -> Unit,
    onCreateProfile: (String, String) -> Unit,
    onDeleteProfile: (String) -> Unit,
    onBindGameToProfile: (String) -> Unit,
    onUpdateSensitivity: (Float, Float, Float) -> Unit,
    onUpdateAimToggleKey: (Int) -> Unit,
    onAddOrUpdateElement: (KeyMappingElement) -> Unit,
    onRemoveElement: (String) -> Unit,
    exportProfileJson: () -> String
) {
    var showCreateProfileDialog by remember { mutableStateOf(false) }
    var showJsonDialog by remember { mutableStateOf(false) }
    var showBindGameDialog by remember { mutableStateOf(false) }

    var sensX by remember(activeProfile.id, activeProfile.sensitivityX) {
        mutableFloatStateOf(activeProfile.sensitivityX)
    }
    var sensY by remember(activeProfile.id, activeProfile.sensitivityY) {
        mutableFloatStateOf(activeProfile.sensitivityY)
    }
    var smoothing by remember(activeProfile.id, activeProfile.dragSmoothing) {
        mutableFloatStateOf(activeProfile.dragSmoothing)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Painel de Permissões Reais
        item {
            SectionHeader(
                title = "Permissões do Motor Keymapper",
                subtitle = "Autorizações reais do Android para sobreposição e toques",
                icon = Icons.Default.Security
            )
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PermissionStatusButton(
                    title = "Sobreposição de Tela (Overlay)",
                    description = "Exibe a bolinha e marcadores sobre qualquer jogo",
                    granted = hasOverlayPermission,
                    icon = Icons.Default.Layers,
                    testTag = "perm_overlay_btn",
                    onClick = onRequestOverlay
                )
                PermissionStatusButton(
                    title = "Motor de Toques (Acessibilidade)",
                    description = "BotxKeymapperAccessibilityService para gestos e teclas",
                    granted = hasAccessibilityEnabled,
                    icon = Icons.Default.AccessibilityNew,
                    testTag = "perm_accessibility_btn",
                    onClick = onRequestAccessibility
                )
                PermissionStatusButton(
                    title = "Modo Shizuku Ultra-Low Latency",
                    description = if (isShizukuReady) "Shizuku conectado e autorizado"
                    else "Toque para conectar ou autorizar o Shizuku",
                    granted = isShizukuReady,
                    icon = Icons.Default.Speed,
                    testTag = "perm_shizuku_btn",
                    onClick = onRequestShizuku
                )
            }
        }

        // Shizuku direct input switch & Overlay Bubble Launcher
        item {
            BotxCard(highlighted = isOverlayRunning) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Injeção Direta via Shizuku",
                            style = MaterialTheme.typography.titleSmall,
                            color = BotxTextPrimary
                        )
                        Text(
                            text = "Usa shell 'input' via UserService quando ativo",
                            style = MaterialTheme.typography.bodyMedium,
                            color = BotxTextSecondary
                        )
                    }
                    Switch(
                        checked = useShizukuInjection,
                        onCheckedChange = onToggleShizukuInput,
                        modifier = Modifier.testTag("shizuku_input_switch"),
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = BotxTextPrimary,
                            checkedTrackColor = BotxNeonRed
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(BotxCardElevated)
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = lastInputLabel,
                        style = MaterialTheme.typography.labelMedium,
                        color = BotxCyan
                    )
                    Text(
                        text = if (isAimModeLocked) "MIRA TRAVADA" else "CURSOR LIVRE",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isAimModeLocked) BotxNeonRed else BotxEmerald
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onToggleFloatingBubble,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("toggle_floating_bubble_btn"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isOverlayRunning) BotxCardElevated else BotxNeonRed,
                        contentColor = BotxTextPrimary
                    )
                ) {
                    Icon(Icons.Default.Gamepad, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isOverlayRunning) "ENCERRAR BOLINHA FLUTUANTE BOTX"
                        else "INICIAR BOLINHA FLUTUANTE BOTX",
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }

        // 2. Gerenciador de Perfis em JSON/DataStore
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionHeader(
                    title = "Perfis por Jogo (JSON)",
                    subtitle = "${profiles.size} layouts salvos no DataStore",
                    icon = Icons.Default.Code
                )
                IconButton(
                    onClick = { showCreateProfileDialog = true },
                    modifier = Modifier.testTag("create_profile_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Novo Perfil", tint = BotxNeonRed)
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                profiles.forEach { profile ->
                    val selected = profile.id == activeProfile.id
                    FilterChip(
                        selected = selected,
                        onClick = { onSelectProfile(profile.id) },
                        label = {
                            Text(
                                text = profile.name,
                                style = MaterialTheme.typography.labelMedium
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BotxNeonRedGlow,
                            selectedLabelColor = BotxNeonRed
                        )
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { showBindGameDialog = true },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Vincular Jogo", style = MaterialTheme.typography.labelMedium)
                }
                OutlinedButton(
                    onClick = { showJsonDialog = true },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Ver JSON", style = MaterialTheme.typography.labelMedium)
                }
                if (profiles.size > 1) {
                    IconButton(onClick = { onDeleteProfile(activeProfile.id) }) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "Excluir perfil",
                            tint = BotxNeonRed
                        )
                    }
                }
            }
        }

        // 3. Controles de Sensibilidade & Tecla Mira/Cursor
        item {
            SectionHeader(
                title = "Sensibilidade e Mira/Cursor",
                subtitle = "Ajuste fino dos eixos e alternância de cursor",
                icon = Icons.Default.Tune
            )
            Spacer(modifier = Modifier.height(8.dp))
            BotxCard {
                SensitivitySliderRow(
                    label = "Sensibilidade Horizontal (Eixo X)",
                    value = sensX,
                    valueRange = 0.3f..3.0f,
                    valueDisplay = "${"%.2f".format(sensX)}x",
                    onValueChange = {
                        sensX = it
                        onUpdateSensitivity(it, sensY, smoothing)
                    }
                )
                Spacer(modifier = Modifier.height(8.dp))
                SensitivitySliderRow(
                    label = "Sensibilidade Vertical (Eixo Y)",
                    value = sensY,
                    valueRange = 0.3f..3.0f,
                    valueDisplay = "${"%.2f".format(sensY)}x",
                    onValueChange = {
                        sensY = it
                        onUpdateSensitivity(sensX, it, smoothing)
                    }
                )
                Spacer(modifier = Modifier.height(8.dp))
                SensitivitySliderRow(
                    label = "Suavização de Arrasto",
                    value = smoothing,
                    valueRange = 0.0f..1.0f,
                    valueDisplay = "${(smoothing * 100).roundToInt()}%",
                    onValueChange = {
                        smoothing = it
                        onUpdateSensitivity(sensX, sensY, it)
                    }
                )

                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Tecla de Alternância Mira / Cursor",
                    style = MaterialTheme.typography.titleSmall,
                    color = BotxTextPrimary
                )
                Spacer(modifier = Modifier.height(6.dp))
                val aimOptions = listOf(
                    KeyEvent.KEYCODE_F to "F",
                    KeyEvent.KEYCODE_CTRL_LEFT to "CTRL",
                    KeyEvent.KEYCODE_ALT_LEFT to "ALT",
                    KeyEvent.KEYCODE_TAB to "TAB"
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    aimOptions.forEach { (code, name) ->
                        FilterChip(
                            selected = activeProfile.aimToggleKeyCode == code,
                            onClick = { onUpdateAimToggleKey(code) },
                            label = { Text(name, style = MaterialTheme.typography.labelSmall) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BotxNeonRedGlow,
                                selectedLabelColor = BotxNeonRed
                            )
                        )
                    }
                }
            }
        }

        // 4. Botões & Macros do Perfil Atual (Edição Rápida + Resumo Coordenadas)
        item {
            SectionHeader(
                title = "Elementos Mapeados (${activeProfile.elements.size})",
                subtitle = "Coordenadas X/Y normalizadas e delays de macro",
                icon = Icons.Default.MyLocation
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        onAddOrUpdateElement(
                            KeyMappingElement(
                                id = "tap_${UUID.randomUUID().toString().take(6)}",
                                type = MappingElementType.TAP,
                                label = "G",
                                keyCode = KeyEvent.KEYCODE_G,
                                xFraction = 0.55f,
                                yFraction = 0.62f
                            )
                        )
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("+ Tap", style = MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(
                    onClick = {
                        val hasWasd = activeProfile.elements.any { it.type == MappingElementType.WASD_ANALOG }
                        if (!hasWasd) {
                            onAddOrUpdateElement(
                                KeyMappingElement(
                                    id = "wasd_${UUID.randomUUID().toString().take(6)}",
                                    type = MappingElementType.WASD_ANALOG,
                                    label = "WASD",
                                    xFraction = 0.18f,
                                    yFraction = 0.68f,
                                    radiusFraction = 0.12f
                                )
                            )
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("+ WASD", style = MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(
                    onClick = {
                        onAddOrUpdateElement(
                            KeyMappingElement(
                                id = "macro_${UUID.randomUUID().toString().take(6)}",
                                type = MappingElementType.COMBO_MACRO,
                                label = "MACRO X",
                                keyCode = KeyEvent.KEYCODE_X,
                                xFraction = 0.72f,
                                yFraction = 0.58f,
                                secondaryXFraction = 0.85f,
                                secondaryYFraction = 0.65f,
                                macroDelayMs = 80
                            )
                        )
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("+ Macro", style = MaterialTheme.typography.labelSmall)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                activeProfile.elements.forEach { el ->
                    BotxCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${el.type.name}: ${el.label} (${KeyCodeFormatter.formatKeyOrMouse(el.keyCode, el.mouseButton)})",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = BotxTextPrimary
                                )
                                val coords = "X=${(el.xFraction * 100).roundToInt()}%  Y=${(el.yFraction * 100).roundToInt()}%" +
                                    when (el.type) {
                                        MappingElementType.WASD_ANALOG -> " • Raio ${(el.radiusFraction * 100).roundToInt()}%"
                                        MappingElementType.COMBO_MACRO -> " • Delay ${el.macroDelayMs}ms"
                                        MappingElementType.TAP -> ""
                                    }
                                Text(
                                    text = coords,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = BotxCyan
                                )
                            }
                            IconButton(onClick = { onRemoveElement(el.id) }) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Remover",
                                    tint = BotxNeonRed,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        if (el.type == MappingElementType.COMBO_MACRO) {
                            Spacer(modifier = Modifier.height(6.dp))
                            var delayVal by remember(el.id, el.macroDelayMs) {
                                mutableFloatStateOf(el.macroDelayMs.toFloat())
                            }
                            Text(
                                text = "Delay entre 2 toques: ${delayVal.roundToInt()} ms",
                                style = MaterialTheme.typography.labelSmall,
                                color = BotxTextSecondary
                            )
                            Slider(
                                value = delayVal,
                                onValueChange = { delayVal = it },
                                onValueChangeFinished = {
                                    onAddOrUpdateElement(el.copy(macroDelayMs = delayVal.roundToInt()))
                                },
                                valueRange = 10f..500f,
                                colors = SliderDefaults.colors(
                                    thumbColor = BotxCyan,
                                    activeTrackColor = BotxCyan
                                )
                            )
                        }
                    }
                }
            }
        }
    }

    if (showCreateProfileDialog) {
        var newName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreateProfileDialog = false },
            title = { Text("Novo Perfil de Mapeamento", style = MaterialTheme.typography.titleMedium) },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text("Nome do perfil (ex: Free Fire Ranked)") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newName.isNotBlank()) {
                        onCreateProfile(newName, "")
                        showCreateProfileDialog = false
                    }
                }) {
                    Text("Salvar", color = BotxNeonRed)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateProfileDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }

    if (showJsonDialog) {
        AlertDialog(
            onDismissRequest = { showJsonDialog = false },
            title = { Text("Layout JSON (${activeProfile.name})", style = MaterialTheme.typography.titleMedium) },
            text = {
                Text(
                    text = exportProfileJson(),
                    style = MaterialTheme.typography.labelSmall,
                    color = BotxCyan
                )
            },
            confirmButton = {
                TextButton(onClick = { showJsonDialog = false }) {
                    Text("Fechar", color = BotxNeonRed)
                }
            }
        )
    }

    if (showBindGameDialog) {
        AlertDialog(
            onDismissRequest = { showBindGameDialog = false },
            title = { Text("Vincular Jogo ao Perfil", style = MaterialTheme.typography.titleMedium) },
            text = {
                LazyColumn(modifier = Modifier.height(260.dp)) {
                    items(installedApps.size) { idx ->
                        val app = installedApps[idx]
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onBindGameToProfile(app.packageName)
                                    showBindGameDialog = false
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = app.label,
                                style = MaterialTheme.typography.bodyLarge,
                                color = BotxTextPrimary
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showBindGameDialog = false }) {
                    Text("Fechar", color = BotxNeonRed)
                }
            }
        )
    }
}

@Composable
private fun SensitivitySliderRow(
    label: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    valueDisplay: String,
    onValueChange: (Float) -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, style = MaterialTheme.typography.titleSmall, color = BotxTextPrimary)
            Text(text = valueDisplay, style = MaterialTheme.typography.labelLarge, color = BotxNeonRed)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            colors = SliderDefaults.colors(
                thumbColor = BotxNeonRed,
                activeTrackColor = BotxNeonRed,
                inactiveTrackColor = BotxCardElevated
            )
        )
    }
}
