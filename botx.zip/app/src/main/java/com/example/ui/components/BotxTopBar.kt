package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.EngineMode
import com.example.data.HardwareTelemetry
import com.example.ui.theme.BotxAmber
import com.example.ui.theme.BotxAmberBg
import com.example.ui.theme.BotxBorderSubtle
import com.example.ui.theme.BotxCardElevated
import com.example.ui.theme.BotxCardSurface
import com.example.ui.theme.BotxCyan
import com.example.ui.theme.BotxEmerald
import com.example.ui.theme.BotxEmeraldBg
import com.example.ui.theme.BotxNeonRed
import com.example.ui.theme.BotxNeonRedGlow
import com.example.ui.theme.BotxObsidianBg
import com.example.ui.theme.BotxTextPrimary
import com.example.ui.theme.BotxTextSecondary

@Composable
fun BotxTopBar(
    telemetry: HardwareTelemetry,
    engineMode: EngineMode,
    modifier: Modifier = Modifier
) {
    val badgeColor = when (engineMode) {
        EngineMode.SHIZUKU -> BotxEmerald
        EngineMode.ACESSIBILIDADE -> BotxCyan
        EngineMode.NATIVO -> BotxAmber
    }
    val badgeBg = when (engineMode) {
        EngineMode.SHIZUKU -> BotxEmeraldBg
        EngineMode.ACESSIBILIDADE -> Color(0x1F00E5FF)
        EngineMode.NATIVO -> BotxAmberBg
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(BotxObsidianBg)
            .statusBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(BotxNeonRed)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "BOTX",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 2.sp
                    ),
                    color = BotxTextPrimary
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TelemetryPill(
                    label = "${telemetry.refreshRateHz}Hz",
                    accent = BotxCyan
                )
                TelemetryPill(
                    label = "${"%.1f".format(telemetry.batteryTempC)}°C",
                    accent = if (telemetry.batteryTempC >= 39f) BotxNeonRed else BotxTextPrimary
                )
                TelemetryPill(
                    label = "${telemetry.usedRamPercent}%",
                    accent = if (telemetry.usedRamPercent >= 85) BotxAmber else BotxTextPrimary
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(badgeBg)
                    .border(1.dp, badgeColor.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = engineMode.badgeLabel,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = badgeColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Text(
                text = "${telemetry.currentDpi} DPI • ${telemetry.batteryPercent}% BAT",
                style = MaterialTheme.typography.labelSmall,
                color = BotxTextSecondary
            )
        }
        HorizontalDivider(color = BotxBorderSubtle, thickness = 1.dp)
    }
}

@Composable
private fun TelemetryPill(label: String, accent: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(BotxCardSurface)
            .border(1.dp, BotxBorderSubtle, RoundedCornerShape(6.dp))
            .padding(horizontal = 7.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = accent,
            maxLines = 1
        )
    }
}
