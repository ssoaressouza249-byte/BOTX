package com.example.system

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import com.example.BuildConfig
import com.example.IBotxUserService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

data class ShellExecResult(
    val success: Boolean,
    val exitCode: Int,
    val output: String
)

object ShizukuBridge {
    private const val SHIZUKU_REQUEST_CODE = 1042

    private val _isBinderAlive = MutableStateFlow(false)
    val isBinderAlive: StateFlow<Boolean> = _isBinderAlive.asStateFlow()

    private val _isPermissionGranted = MutableStateFlow(false)
    val isPermissionGranted: StateFlow<Boolean> = _isPermissionGranted.asStateFlow()

    private val _isUserServiceConnected = MutableStateFlow(false)
    val isUserServiceConnected: StateFlow<Boolean> = _isUserServiceConnected.asStateFlow()

    @Volatile
    private var userService: IBotxUserService? = null
    private var initialized = false

    private val userServiceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            userService = IBotxUserService.Stub.asInterface(service)
            _isUserServiceConnected.value = userService != null
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            userService = null
            _isUserServiceConnected.value = false
        }
    }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        refreshStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        _isBinderAlive.value = false
        _isPermissionGranted.value = false
        _isUserServiceConnected.value = false
        userService = null
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == SHIZUKU_REQUEST_CODE) {
                val granted = grantResult == PackageManager.PERMISSION_GRANTED
                _isPermissionGranted.value = granted
                if (granted) {
                    bindUserServiceIfNeeded()
                }
            }
        }

    fun init() {
        if (initialized) {
            refreshStatus()
            return
        }
        initialized = true
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(permissionResultListener)
            refreshStatus()
        } catch (_: Throwable) {
        }
    }

    fun refreshStatus() {
        val alive = try {
            Shizuku.pingBinder()
        } catch (_: Throwable) {
            false
        }
        _isBinderAlive.value = alive
        if (!alive) {
            _isPermissionGranted.value = false
            _isUserServiceConnected.value = false
            return
        }
        val granted = try {
            if (Shizuku.isPreV11()) false
            else Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Throwable) {
            false
        }
        _isPermissionGranted.value = granted
        if (granted) {
            bindUserServiceIfNeeded()
        }
    }

    fun requestPermission(context: Context): Boolean {
        refreshStatus()
        if (!_isBinderAlive.value) return false
        return try {
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                _isPermissionGranted.value = true
                bindUserServiceIfNeeded()
                true
            } else {
                Shizuku.requestPermission(SHIZUKU_REQUEST_CODE)
                true
            }
        } catch (_: Throwable) {
            false
        }
    }

    private fun bindUserServiceIfNeeded() {
        if (userService != null) {
            _isUserServiceConnected.value = true
            return
        }
        try {
            val args = Shizuku.UserServiceArgs(
                ComponentName(BuildConfig.APPLICATION_ID, BotxUserService::class.java.name)
            )
                .daemon(false)
                .processNameSuffix("botx_shell")
                .debuggable(BuildConfig.DEBUG)
                .version(BuildConfig.VERSION_CODE)
            Shizuku.bindUserService(args, userServiceConnection)
        } catch (_: Throwable) {
        }
    }

    fun isReady(): Boolean = _isBinderAlive.value && _isPermissionGranted.value

    suspend fun executeShell(command: String): ShellExecResult = withContext(Dispatchers.IO) {
        refreshStatus()
        if (!isReady()) {
            return@withContext ShellExecResult(
                success = false,
                exitCode = -1,
                output = "Shizuku não está ativo ou sem permissão concedida."
            )
        }
        if (userService == null) {
            bindUserServiceIfNeeded()
            // Brief wait for binder attachment
            repeat(10) {
                if (userService != null) return@repeat
                kotlinx.coroutines.delay(50)
            }
        }
        val svc = userService ?: return@withContext ShellExecResult(
            success = false,
            exitCode = -1,
            output = "BotxUserService não conectado ao Shizuku."
        )
        return@withContext try {
            val raw = svc.exec(command)
            val firstNewline = raw.indexOf('\n')
            val header = if (firstNewline >= 0) raw.substring(0, firstNewline) else raw
            val body = if (firstNewline >= 0) raw.substring(firstNewline + 1) else ""
            val code = header.removePrefix("EXIT:").toIntOrNull() ?: -1
            ShellExecResult(success = code == 0, exitCode = code, output = body)
        } catch (t: Throwable) {
            ShellExecResult(success = false, exitCode = -1, output = t.message ?: "Erro IPC")
        }
    }

    fun injectTapAsync(x: Int, y: Int): Boolean {
        val svc = userService ?: return false
        return try {
            svc.injectTap(x, y)
            true
        } catch (_: Throwable) {
            false
        }
    }

    fun injectSwipeAsync(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Int): Boolean {
        val svc = userService ?: return false
        return try {
            svc.injectSwipe(x1, y1, x2, y2, durationMs)
            true
        } catch (_: Throwable) {
            false
        }
    }
}
