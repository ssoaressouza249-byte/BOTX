package com.example.system

import android.app.Activity
import android.app.ActivityManager
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.hardware.input.InputManager
import android.net.ConnectivityManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Display
import android.view.InputDevice
import android.view.WindowManager
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.data.HardwareTelemetry
import com.example.data.InstalledAppInfo
import com.example.data.PeripheralDevice
import com.example.data.PingSample
import com.example.service.BotxKeymapperAccessibilityService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.abs
import kotlin.math.roundToInt

class SystemOptimizerEngine(private val context: Context) {

    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val inputManager = context.getSystemService(Context.INPUT_SERVICE) as InputManager
    private val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    private val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private val baselineDpi: Int = context.resources.displayMetrics.densityDpi

    fun hasOverlayPermission(): Boolean = Settings.canDrawOverlays(context)

    fun hasWriteSettingsPermission(): Boolean = Settings.System.canWrite(context)

    fun hasDndPermission(): Boolean = notificationManager.isNotificationPolicyAccessGranted

    fun isAccessibilityEnabled(): Boolean {
        if (KeymapperRuntimeState.isAccessibilityConnected.value) return true
        val expected = ComponentName(context, BotxKeymapperAccessibilityService::class.java).flattenToString()
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    fun openOverlayPermissionSettings() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    fun openWriteSettingsPermission() {
        val intent = Intent(
            Settings.ACTION_MANAGE_WRITE_SETTINGS,
            Uri.parse("package:${context.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    fun openDndPermissionSettings() {
        val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    fun openBackgroundDataSettings() {
        val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Intent(
                Settings.ACTION_IGNORE_BACKGROUND_DATA_RESTRICTIONS_SETTINGS,
                Uri.parse("package:${context.packageName}")
            )
        } else {
            Intent(Settings.ACTION_WIRELESS_SETTINGS)
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }.onFailure {
            context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    fun readHardwareTelemetry(): HardwareTelemetry {
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)
        val totalRamMb = memInfo.totalMem / (1024L * 1024L)
        val availRamMb = memInfo.availMem / (1024L * 1024L)
        val usedPercent = if (totalRamMb > 0) {
            (((totalRamMb - availRamMb).toFloat() / totalRamMb.toFloat()) * 100f).roundToInt().coerceIn(0, 100)
        } else 0

        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val batteryPct = if (level >= 0 && scale > 0) (level * 100) / scale else 0
        val tempTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 300) ?: 300
        val voltageMv = batteryIntent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val display = displayManager.getDisplay(Display.DEFAULT_DISPLAY)
        val currentHz = display?.refreshRate?.roundToInt() ?: 60
        val availableHz = display?.supportedModes
            ?.map { it.refreshRate.roundToInt() }
            ?.distinct()
            ?.sorted()
            ?: listOf(60)

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        display?.getRealMetrics(metrics)
        val currentDpi = if (metrics.densityDpi > 0) metrics.densityDpi else baselineDpi

        return HardwareTelemetry(
            deviceModel = "${Build.MANUFACTURER.uppercase()} ${Build.MODEL}",
            manufacturer = Build.MANUFACTURER,
            androidVersion = Build.VERSION.RELEASE,
            apiLevel = Build.VERSION.SDK_INT,
            cpuCores = Runtime.getRuntime().availableProcessors(),
            cpuAbi = Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a",
            totalRamMb = totalRamMb,
            availableRamMb = availRamMb,
            usedRamPercent = usedPercent,
            batteryPercent = batteryPct,
            batteryTempC = tempTenths / 10f,
            batteryVoltageMv = voltageMv,
            isCharging = charging,
            refreshRateHz = currentHz,
            availableRefreshRatesHz = availableHz,
            currentDpi = currentDpi,
            defaultDpi = baselineDpi
        )
    }

    fun detectConnectedPeripherals(): List<PeripheralDevice> {
        val result = mutableListOf<PeripheralDevice>()
        val ids = inputManager.inputDeviceIds
        for (id in ids) {
            val dev = inputManager.getInputDevice(id) ?: continue
            val isVirtual = dev.isVirtual
            val sources = dev.sources
            val isMouse = (sources and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE ||
                (sources and InputDevice.SOURCE_MOUSE_RELATIVE) == InputDevice.SOURCE_MOUSE_RELATIVE
            val isKeyboard = (sources and InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD &&
                dev.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC
            if (!isVirtual && (isMouse || isKeyboard)) {
                result.add(
                    PeripheralDevice(
                        id = dev.id,
                        name = dev.name.ifBlank { "Dispositivo HID #${dev.id}" },
                        descriptor = dev.descriptor,
                        isMouse = isMouse,
                        isKeyboard = isKeyboard,
                        vendorId = dev.vendorId,
                        productId = dev.productId
                    )
                )
            }
        }
        return result
    }

    suspend fun loadInstalledApps(): List<InstalledAppInfo> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val packages = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(PackageManager.GET_META_DATA.toLong()))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledApplications(PackageManager.GET_META_DATA)
        }
        val gameHints = listOf(
            "freefire", "pubg", "codm", "callofduty", "brawlstars", "roblox",
            "minecraft", "genshin", "mobile.legends", "wildrift", "fortnite",
            "valorant", "stumble", "farlight", "arena", "standoff", "bloodstrike"
        )
        packages
            .filter { it.packageName != context.packageName && pm.getLaunchIntentForPackage(it.packageName) != null }
            .map { app ->
                val isSys = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                val isGameCategory = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    app.category == ApplicationInfo.CATEGORY_GAME
                } else {
                    @Suppress("DEPRECATION")
                    (app.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                }
                val lowerPkg = app.packageName.lowercase()
                val matchesHint = gameHints.any { lowerPkg.contains(it) }
                InstalledAppInfo(
                    packageName = app.packageName,
                    label = pm.getApplicationLabel(app).toString(),
                    isGame = isGameCategory || matchesHint,
                    isSystemApp = isSys,
                    isEnabled = app.enabled
                )
            }
            .sortedWith(compareByDescending<InstalledAppInfo> { it.isGame }.thenBy { it.label.lowercase() })
    }

    fun launchPackage(packageName: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    suspend fun cleanIdleRam(): Long = withContext(Dispatchers.IO) {
        val beforeMem = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(beforeMem)

        val pm = context.packageManager
        val apps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledApplications(0)
        }
        for (app in apps) {
            if (app.packageName != context.packageName) {
                runCatching { activityManager.killBackgroundProcesses(app.packageName) }
            }
        }
        System.gc()

        val afterMem = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(afterMem)
        val freedBytes = (afterMem.availMem - beforeMem.availMem).coerceAtLeast(0L)
        freedBytes / (1024L * 1024L)
    }

    fun setDoNotDisturb(enabled: Boolean): Boolean {
        if (!hasDndPermission()) return false
        return try {
            notificationManager.setInterruptionFilter(
                if (enabled) NotificationManager.INTERRUPTION_FILTER_PRIORITY
                else NotificationManager.INTERRUPTION_FILTER_ALL
            )
            true
        } catch (_: SecurityException) {
            false
        }
    }

    suspend fun setPointerSpeed(speed: Int): Boolean {
        val clamped = speed.coerceIn(-7, 7)
        if (hasWriteSettingsPermission()) {
            val ok = runCatching {
                Settings.System.putInt(context.contentResolver, "pointer_speed", clamped)
            }.getOrDefault(false)
            if (ok) return true
        }
        if (ShizukuBridge.isReady()) {
            return ShizukuBridge.executeShell("settings put system pointer_speed $clamped").success
        }
        return false
    }

    fun readPointerSpeed(): Int {
        return runCatching {
            Settings.System.getInt(context.contentResolver, "pointer_speed", 0)
        }.getOrDefault(0).coerceIn(-7, 7)
    }

    suspend fun setLongPressTimeout(timeoutMs: Int): Boolean {
        val clamped = timeoutMs.coerceIn(100, 1000)
        if (ShizukuBridge.isReady()) {
            if (ShizukuBridge.executeShell("settings put secure long_press_timeout $clamped").success) {
                return true
            }
        }
        return runCatching {
            Settings.Secure.putInt(context.contentResolver, "long_press_timeout", clamped)
        }.getOrDefault(false)
    }

    fun readLongPressTimeout(): Int {
        return runCatching {
            Settings.Secure.getInt(context.contentResolver, "long_press_timeout", 400)
        }.getOrDefault(400)
    }

    suspend fun setTouchSensitivity(enabled: Boolean): Boolean {
        val value = if (enabled) 1 else 0
        if (hasWriteSettingsPermission()) {
            val ok = runCatching {
                Settings.System.putInt(context.contentResolver, "touch_sensitivity", value)
            }.getOrDefault(false)
            if (ok) return true
        }
        if (ShizukuBridge.isReady()) {
            val r1 = ShizukuBridge.executeShell("settings put system touch_sensitivity $value")
            val r2 = ShizukuBridge.executeShell("settings put secure touch_sensitivity $value")
            return r1.success || r2.success
        }
        return false
    }

    suspend fun setLandscapeLock(activity: Activity?, locked: Boolean): Boolean {
        activity?.requestedOrientation = if (locked) {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        val accelVal = if (locked) 0 else 1
        var settingsUpdated = false
        if (hasWriteSettingsPermission()) {
            settingsUpdated = runCatching {
                Settings.System.putInt(context.contentResolver, Settings.System.ACCELEROMETER_ROTATION, accelVal)
                if (locked) {
                    Settings.System.putInt(context.contentResolver, Settings.System.USER_ROTATION, 1)
                }
                true
            }.getOrDefault(false)
        } else if (ShizukuBridge.isReady()) {
            val res = ShizukuBridge.executeShell(
                "settings put system accelerometer_rotation $accelVal" +
                    if (locked) " && settings put system user_rotation 1" else ""
            )
            settingsUpdated = res.success
        }
        return settingsUpdated || activity != null
    }

    suspend fun setImmersiveMode(activity: Activity?, enabled: Boolean): Boolean {
        if (activity != null) {
            val controller = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            if (enabled) {
                controller.hide(WindowInsetsCompat.Type.systemBars())
            } else {
                controller.show(WindowInsetsCompat.Type.systemBars())
            }
        }
        if (ShizukuBridge.isReady()) {
            val policy = if (enabled) "immersive.full=*" else "null"
            ShizukuBridge.executeShell("settings put global policy_control $policy")
        }
        return activity != null || ShizukuBridge.isReady()
    }

    suspend fun applyCustomDpi(dpi: Int): ShellExecResult {
        val clamped = dpi.coerceIn(160, 960)
        return ShizukuBridge.executeShell("wm density $clamped")
    }

    suspend fun resetDpi(): ShellExecResult {
        return ShizukuBridge.executeShell("wm density reset")
    }

    suspend fun setZeroAnimations(enabled: Boolean): Boolean {
        val scale = if (enabled) "0.0" else "1.0"
        if (ShizukuBridge.isReady()) {
            val cmd = "settings put global window_animation_scale $scale && " +
                "settings put global transition_animation_scale $scale && " +
                "settings put global animator_duration_scale $scale"
            return ShizukuBridge.executeShell(cmd).success
        }
        return false
    }

    suspend fun forceMaxRefreshRate(activity: Activity?, enabled: Boolean): Int {
        val display = displayManager.getDisplay(Display.DEFAULT_DISPLAY)
        val modes = display?.supportedModes ?: emptyArray()
        val maxMode = modes.maxByOrNull { it.refreshRate }
        val targetHz = maxMode?.refreshRate?.roundToInt() ?: 60

        if (activity != null && maxMode != null) {
            val params: WindowManager.LayoutParams = activity.window.attributes
            params.preferredDisplayModeId = if (enabled) maxMode.modeId else 0
            activity.window.attributes = params
        }

        if (ShizukuBridge.isReady()) {
            if (enabled) {
                ShizukuBridge.executeShell(
                    "settings put system peak_refresh_rate $targetHz.0 && settings put system min_refresh_rate $targetHz.0"
                )
            } else {
                ShizukuBridge.executeShell(
                    "settings delete system min_refresh_rate && settings put system peak_refresh_rate 60.0"
                )
            }
        }
        return targetHz
    }

    suspend fun compileAotSpeed(packageName: String): ShellExecResult {
        return ShizukuBridge.executeShell("cmd package compile -m speed -f $packageName")
    }

    suspend fun setHapticDisabled(disabled: Boolean): Boolean {
        val value = if (disabled) 0 else 1
        if (hasWriteSettingsPermission()) {
            val ok = runCatching {
                Settings.System.putInt(context.contentResolver, Settings.System.HAPTIC_FEEDBACK_ENABLED, value)
            }.getOrDefault(false)
            if (ok) return true
        }
        if (ShizukuBridge.isReady()) {
            return ShizukuBridge.executeShell("settings put system haptic_feedback_enabled $value").success
        }
        return false
    }

    fun applyThermalBrightnessReduction(reduce: Boolean): Boolean {
        if (!hasWriteSettingsPermission()) return false
        return runCatching {
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS,
                if (reduce) 85 else 180
            )
            true
        }.getOrDefault(false)
    }

    suspend fun disableCaptivePortalChecks(): ShellExecResult {
        return ShizukuBridge.executeShell(
            "settings put global captive_portal_mode 0 && settings put global captive_portal_detection_enabled 0"
        )
    }

    suspend fun forceStopApp(packageName: String): ShellExecResult {
        return ShizukuBridge.executeShell("am force-stop $packageName")
    }

    suspend fun setAppFrozen(packageName: String, freeze: Boolean): ShellExecResult {
        val cmd = if (freeze) "pm disable-user --user 0 $packageName" else "pm enable $packageName"
        return ShizukuBridge.executeShell(cmd)
    }

    fun getBackgroundRestrictionStatusLabel(): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            when (connectivityManager.restrictBackgroundStatus) {
                ConnectivityManager.RESTRICT_BACKGROUND_STATUS_ENABLED -> "Economia de Dados ATIVA"
                ConnectivityManager.RESTRICT_BACKGROUND_STATUS_WHITELISTED -> "Lista de Permissões"
                else -> "Sem Restrição"
            }
        } else {
            "Sistema Padrão"
        }
    }

    suspend fun measurePingSample(previousDns1Ms: Int?): PingSample = withContext(Dispatchers.IO) {
        val dns1 = measureTcpLatencyMs("1.1.1.1", 53)
        val dns8 = measureTcpLatencyMs("8.8.8.8", 53)
        val loss = dns1 < 0 && dns8 < 0
        val effectiveDns1 = if (dns1 >= 0) dns1 else 999
        val effectiveDns8 = if (dns8 >= 0) dns8 else 999
        val jitter = if (previousDns1Ms != null && dns1 >= 0 && previousDns1Ms < 900) {
            abs(dns1 - previousDns1Ms)
        } else {
            0
        }
        PingSample(
            timestampMs = System.currentTimeMillis(),
            dns1Ms = effectiveDns1,
            dns8Ms = effectiveDns8,
            jitterMs = jitter,
            packetLoss = loss
        )
    }

    private fun measureTcpLatencyMs(host: String, port: Int): Int {
        return try {
            val startNs = System.nanoTime()
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), 1500)
            }
            val elapsedMs = ((System.nanoTime() - startNs) / 1_000_000L).toInt()
            elapsedMs.coerceAtLeast(1)
        } catch (_: Throwable) {
            -1
        }
    }
}
