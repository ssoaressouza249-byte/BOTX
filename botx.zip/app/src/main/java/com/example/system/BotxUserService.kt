package com.example.system

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import com.example.IBotxUserService
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.system.exitProcess

class BotxUserService() : IBotxUserService.Stub() {

    @Suppress("UNUSED_PARAMETER")
    constructor(context: Context) : this()

    override fun destroy() {
        exitProcess(0)
    }

    override fun exec(command: String): String {
        return try {
            val process = ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(true)
                .start()
            val output = BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                reader.readText()
            }
            val code = process.waitFor()
            "EXIT:$code\n${output.trim()}"
        } catch (t: Throwable) {
            "EXIT:-1\n${t.message ?: "Erro ao executar comando"}"
        }
    }

    override fun injectTap(x: Int, y: Int) {
        try {
            ProcessBuilder("input", "tap", x.toString(), y.toString())
                .redirectErrorStream(true)
                .start()
                .waitFor()
        } catch (_: Throwable) {
        }
    }

    override fun injectSwipe(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Int) {
        try {
            ProcessBuilder(
                "input",
                "swipe",
                x1.toString(),
                y1.toString(),
                x2.toString(),
                y2.toString(),
                durationMs.coerceAtLeast(16).toString()
            )
                .redirectErrorStream(true)
                .start()
                .waitFor()
        } catch (_: Throwable) {
        }
    }
}
