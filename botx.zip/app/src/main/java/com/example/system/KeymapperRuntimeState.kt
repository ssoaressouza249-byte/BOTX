package com.example.system

import com.example.data.KeyMappingElement
import com.example.data.KeymapProfile
import com.example.data.ProfileRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

object KeymapperRuntimeState {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _activeProfile = MutableStateFlow(ProfileRepository.defaultProfiles().first())
    val activeProfile: StateFlow<KeymapProfile> = _activeProfile.asStateFlow()

    private val _isAccessibilityConnected = MutableStateFlow(false)
    val isAccessibilityConnected: StateFlow<Boolean> = _isAccessibilityConnected.asStateFlow()

    private val _isOverlayRunning = MutableStateFlow(false)
    val isOverlayRunning: StateFlow<Boolean> = _isOverlayRunning.asStateFlow()

    private val _isMappingActive = MutableStateFlow(true)
    val isMappingActive: StateFlow<Boolean> = _isMappingActive.asStateFlow()

    private val _isAimModeLocked = MutableStateFlow(false)
    val isAimModeLocked: StateFlow<Boolean> = _isAimModeLocked.asStateFlow()

    private val _useShizukuInjection = MutableStateFlow(false)
    val useShizukuInjection: StateFlow<Boolean> = _useShizukuInjection.asStateFlow()

    private val _lastInputEventLabel = MutableStateFlow("Aguardando entrada...")
    val lastInputEventLabel: StateFlow<String> = _lastInputEventLabel.asStateFlow()

    private val _profileModifiedFromOverlay = MutableSharedFlow<KeymapProfile>(extraBufferCapacity = 8)
    val profileModifiedFromOverlay: SharedFlow<KeymapProfile> = _profileModifiedFromOverlay.asSharedFlow()

    fun setActiveProfile(profile: KeymapProfile) {
        _activeProfile.value = profile
    }

    fun updateProfileFromOverlay(updated: KeymapProfile) {
        _activeProfile.value = updated
        scope.launch {
            _profileModifiedFromOverlay.emit(updated)
        }
    }

    fun addOrUpdateElement(element: KeyMappingElement) {
        val current = _activeProfile.value
        val existingIdx = current.elements.indexOfFirst { it.id == element.id }
        val newList = current.elements.toMutableList()
        if (existingIdx >= 0) {
            newList[existingIdx] = element
        } else {
            newList.add(element)
        }
        updateProfileFromOverlay(current.copy(elements = newList))
    }

    fun removeElement(elementId: String) {
        val current = _activeProfile.value
        updateProfileFromOverlay(current.copy(elements = current.elements.filterNot { it.id == elementId }))
    }

    fun setAccessibilityConnected(connected: Boolean) {
        _isAccessibilityConnected.value = connected
    }

    fun setOverlayRunning(running: Boolean) {
        _isOverlayRunning.value = running
    }

    fun setMappingActive(active: Boolean) {
        _isMappingActive.value = active
    }

    fun toggleAimMode() {
        _isAimModeLocked.value = !_isAimModeLocked.value
    }

    fun setUseShizukuInjection(useShizuku: Boolean) {
        _useShizukuInjection.value = useShizuku
    }

    fun reportInputEvent(label: String) {
        _lastInputEventLabel.value = label
    }
}
