package com.example;

interface IBotxUserService {
    void destroy() = 16777114;
    String exec(String command) = 1;
    void injectTap(int x, int y) = 2;
    void injectSwipe(int x1, int y1, int x2, int y2, int durationMs) = 3;
}
